/*
 * Runs ONLY inside the user's selected HTML document, in that document's JS world.
 * This adapter has no prompt rules, replacement tags, default costumes, JSON cache,
 * or alternative optimization algorithm. All domain operations call the bound HTML.
 */
(() => {
  'use strict';
  if (window.__comfyPetBoundBridgeV1) return 'ready';
  let selectedCharacter = null;
  let pendingResult = '';
  const input = () => document.getElementById('promptInput');
  const el = (id) => document.getElementById(id);
  const found = (name, f) => { if (typeof f !== 'function') throw new Error('綁定的 HTML 不支援「' + name + '」，請確認版本。'); return f; };
  const asText = (v, max = 300000) => String(v == null ? '' : v).slice(0, max);
  const value = () => {
    const field = input();
    if (!field) throw new Error('綁定的 HTML 沒有 promptInput 輸入框。');
    return field.value || '';
  };
  const setValue = (v) => {
    const field = input();
    if (!field) throw new Error('綁定的 HTML 沒有 promptInput 輸入框。');
    field.value = asText(v);
    field.dispatchEvent(new Event('input', { bubbles: true }));
    return field.value;
  };
  const db = () => {
    let array = [];
    try { if (typeof COS_DB !== 'undefined' && Array.isArray(COS_DB)) array = COS_DB; } catch (_) {}
    if (!array.length && Array.isArray(window.COS_DB)) array = window.COS_DB;
    return array;
  };
  const currentCharacter = () => ({
    char: asText(el('cosChar')?.value || selectedCharacter?.char || '', 256),
    series: asText(el('cosSeries')?.value || selectedCharacter?.series || '', 256)
  });
  const result = () => {
    try { if (typeof lastOptimized === 'string' && lastOptimized.trim()) return lastOptimized; } catch (_) {}
    const text = (el('diffAfter')?.textContent || '').trim();
    return text && !/尚未再次優化|尚未優化/.test(text) ? text : '';
  };
  const capabilities = () => ({
    optimize: typeof window.simpleOptimize === 'function' || typeof window.optimizePrompt === 'function',
    apply: typeof window.applyOptimizedPromptFloat === 'function',
    clear: typeof window.clearPrompt === 'function',
    characters: typeof window.selectCosplayer === 'function' && typeof window.simpleApplyLook === 'function',
    outfits: typeof window.getCharacterOutfitSets === 'function' && typeof window.applyCharacterOutfit === 'function',
    folder: !!(el('dataFolderStatus') || el('dataFolderPath'))
  });
  const status = () => {
    const folderState = asText(el('dataFolderStatus')?.textContent || '', 260).trim();
    const folderPath = asText(el('dataFolderPath')?.textContent || '', 320).trim();
    const current = currentCharacter();
    return {
      title: document.title, prompt: input() ? value() : '',
      capabilities: capabilities(), characters: db().length,
      selected: current, folderState, folderPath,
      ready: !!input(), result: pendingResult
    };
  };
  // Search-only bilingual aliases; this list never edits prompt text or outfits JSON.
  // Keep 'bikini' separate from generic swimsuit, and school uniform separate
  // from school swimsuit, to avoid turning a related term into a false result.
  const OUTFIT_ALIASES = [
    ['比基尼', '三點式', 'bikini', 'bikinis', 'two piece bikini', 'two-piece bikini'],
    ['白色', '純白色', 'white'],
    ['黑色', 'black'], ['紅色', 'red'], ['藍色', 'blue'],
    ['粉紅色', '粉色', 'pink'], ['黃色', 'yellow'], ['綠色', 'green'],
    ['紫色', 'purple'], ['灰色', 'grey', 'gray'], ['棕色', '褐色', 'brown'],
    ['金色', 'gold', 'golden'], ['銀色', 'silver'], ['橘色', '橙色', 'orange'],
    ['泳裝', '泳衣', 'swimsuit', 'swimwear', 'bathing suit'],
    ['校服', '學校制服', 'school uniform', 'school_uniform'],
    ['女僕裝', '女僕服', '女僕', 'maid outfit', 'maid dress', 'maid uniform', 'maid'],
    ['和服', 'kimono'], ['浴衣', 'yukata'], ['禮服', 'dress', 'gown'],
    ['裙子', '短裙', 'skirt'], ['洋裝', '連身裙', 'dress'],
    ['盔甲', '鎧甲', 'armor', 'armour'], ['護士服', 'nurse outfit', 'nurse uniform'],
    ['兔女郎', 'bunny suit', 'bunny girl', 'bunnysuit'],
    ['旗袍', 'cheongsam', 'qipao'],
    ['絲襪', 'stockings', 'pantyhose'], ['過膝襪', 'thighhighs', 'thigh highs'],
    ['外套', 'jacket', 'coat'], ['襯衫', 'shirt', 'blouse'],
    ['泳帽', 'swim cap', 'swimcap']
  ];
  const normFind = (v) => asText(v, 4000).normalize('NFKC').toLowerCase()
    .replace(/[_\-]+/g, ' ').replace(/\s+/g, ' ').trim();
  // Split known Chinese compounds without splitting a person's Chinese name.
  const CN_COMPOUNDS = OUTFIT_ALIASES.flatMap(group => group.filter(x => /[\u3400-\u9fff]/.test(x) && x.length >= 2))
    .sort((a,b) => b.length - a.length);
  function searchTerms(raw) {
    let text = normFind(asText(raw, 140));
    // Allows '白色比基尼' and '白色 比基尼' to express the same AND query.
    const compounds = new RegExp('(' + CN_COMPOUNDS.join('|') + ')', 'g');
    text = text.replace(compounds, ' $1 ');
    return text.split(/[\s,，、;；/]+/).filter(Boolean).slice(0, 12);
  }
  function aliasFor(term) {
    const group = OUTFIT_ALIASES.find(g => g.some(a => normFind(a) === term));
    return group ? Array.from(new Set(group.map(normFind))) : [term];
  }
  function searchOutfits(query, offset = 0, limit = 100) {
    const terms = searchTerms(query);
    const charDb = db();
    if (!terms.length) return { total: 0, list: [], selected: currentCharacter() };
    const searchGroups = terms.map(aliasFor);
    const setsFor = found('服飾資料', window.getCharacterOutfitSets);
    const results = [];
    const seen = new Set();
    for (const role of charDb) {
      if (!role || !role.char) continue;
      const char = asText(role.char, 256), series = asText(role.series, 256);
      const key = normFind(char) + '\x00' + normFind(series);
      if (seen.has(key)) continue;
      seen.add(key);
      let sets = [];
      try { sets = setsFor(char, series); } catch (e) { continue; }
      if (!Array.isArray(sets)) continue;
      const cn = asText(Array.isArray(role.cn) ? role.cn.join(' / ') : role.cn, 200);
      const who = normFind([char, series, cn].join(' '));
      for (let index = 0; index < sets.length; index++) {
        const outfit = sets[index];
        if (!outfit) continue;
        const name = asText(outfit.name || outfit.label || '未命名', 150);
        const tags = Array.isArray(outfit.tags) ? outfit.tags.map(x => asText(x, 250)).join(', ') : '';
        const descriptions = [outfit.cn, outfit.description, outfit.desc, outfit.note, outfit.zh]
          .filter(x => typeof x === 'string').join(' ');
        const clothing = normFind(name + ' ' + tags + ' ' + descriptions);
        const searchable = clothing + ' ' + who;
        if (!searchGroups.every(group => group.some(alias => searchable.includes(alias)))) continue;
        const nameText = normFind(name);
        const matchedName = searchGroups.filter(group => group.some(alias => nameText.includes(alias))).length;
        const matchedCloth = searchGroups.filter(group => group.some(alias => clothing.includes(alias))).length;
        results.push({ char, series, cn, index, name, preview: asText(tags, 500),
          rank: matchedName * 3 + matchedCloth * 2 });
      }
    }
    results.sort((a,b) => b.rank - a.rank || a.series.localeCompare(b.series) || a.char.localeCompare(b.char) || a.index - b.index);
    const start = Math.max(0, Math.min(100000, Number(offset) || 0));
    const count = Math.max(1, Math.min(100, Number(limit) || 100));
    return { total: results.length, list: results.slice(start, start + count), selected: currentCharacter(), offset: start };
  }
  // Search-only character appearance aliases. Character data always comes from the
  // bound HTML's live COS_DB; no character attributes are hardcoded or inferred.
  // Hair, eyes and outfit concepts are intentionally NOT conflated.
  const APPEARANCE_ALIASES = [
    ['金髮','金色頭髮','金色髮色','blonde hair','blond hair','blonde','blond'],
    ['黑髮','黑色頭髮','black hair'],
    ['白髮','白色頭髮','white hair'],
    ['銀髮','銀色頭髮','silver hair'],
    ['灰髮','灰色頭髮','grey hair','gray hair'],
    ['紅髮','紅色頭髮','red hair'],
    ['橘髮','橙髮','橘色頭髮','orange hair'],
    ['棕髮','褐髮','咖啡色頭髮','brown hair'],
    ['藍髮','藍色頭髮','blue hair'],
    ['綠髮','綠色頭髮','green hair'],
    ['粉髮','粉紅髮','粉色頭髮','pink hair'],
    ['紫髮','紫色頭髮','purple hair'],
    ['黃髮','黃色頭髮','yellow hair'],
    ['紅眼','紅瞳','紅色眼睛','red eyes','red eye'],
    ['藍眼','藍瞳','藍色眼睛','blue eyes','blue eye'],
    ['綠眼','綠瞳','綠色眼睛','green eyes','green eye'],
    ['金眼','金瞳','金色眼睛','golden eyes','gold eyes'],
    ['黃眼','黃瞳','黃色眼睛','yellow eyes'],
    ['紫眼','紫瞳','紫色眼睛','purple eyes'],
    ['粉眼','粉紅眼','粉紅色眼睛','pink eyes'],
    ['黑眼','黑瞳','黑色眼睛','black eyes'],
    ['白眼','白瞳','白色眼睛','white eyes'],
    ['棕眼','褐眼','棕瞳','brown eyes'],
    ['灰眼','灰瞳','grey eyes','gray eyes'],
    ['異色瞳','異色眼','不同顏色眼睛','heterochromia','odd eyes','different colored eyes','different coloured eyes'],
    ['長髮','長頭髮','long hair','very long hair'],
    ['短髮','短頭髮','short hair','very short hair'],
    ['中長髮','及肩髮','medium hair','medium length hair','shoulder length hair'],
    ['直髮','straight hair'], ['捲髮','卷髮','curly hair','wavy hair'],
    ['馬尾','單馬尾','ponytail','high ponytail','low ponytail','side ponytail'],
    ['雙馬尾','雙辮','twintails','twin tails','twin ponytails','pigtails'],
    ['雙側束髮','雙側紮髮','two side up'],
    ['辮子','編髮','麻花辮','braid','braids','braided hair'],
    ['丸子頭','髮髻','包包頭','hair bun','hair buns','double bun'],
    ['妹妹頭','齊劉海','整齊瀏海','blunt bangs','straight bangs'],
    ['瀏海','劉海','bangs','fringe'],
    ['側瀏海','旁分瀏海','side bangs','swept bangs','side swept bangs'],
    ['呆毛','ahoge'],
    ['短鮑伯','鮑伯頭','bob cut','bob hair'],
    ['挑染','多色頭髮','multicolored hair','streaked hair','colored streaks'],
    ['漸層髮','漸層染髮','gradient hair','ombre hair'],
    ['貓耳','cat ears'], ['狐耳','狐狸耳朵','fox ears'],
    ['兔耳','兔子耳朵','rabbit ears','bunny ears'],
    ['獸耳','動物耳朵','animal ears'],
    ['角','頭角','horn','horns'], ['光環','頭頂光環','halo'],
    ['眼鏡','glasses','eyeglasses','spectacles'],
    ['雀斑','freckles'], ['痣','美人痣','mole','beauty mark'],
    ['髮飾','頭飾','hair ornament','hair ornaments','hair accessory','hair accessories'],
    ['髮帶','頭帶','headband'], ['緞帶','蝴蝶結','ribbon','hair ribbon'],
    ['白色','white'], ['黑色','black'], ['紅色','red'], ['藍色','blue'],
    ['綠色','green'], ['金色','gold','golden'], ['黃色','yellow'],
    ['粉紅色','粉色','pink'], ['紫色','purple'], ['銀色','silver'],
    ['棕色','褐色','brown'], ['灰色','grey','gray'], ['橘色','橙色','orange']
  ];
  const appearanceCN = Array.from(new Set(APPEARANCE_ALIASES.flatMap(group => group
    .filter(alias => /[\u3400-\u9fff]/.test(alias) && alias.length > 1))))
    .sort((a, b) => b.length - a.length);
  const appearanceEnglish = Array.from(new Set(APPEARANCE_ALIASES.flatMap(group => group
    .map(normFind).filter(alias => /^[a-z]+(?: [a-z]+)+$/.test(alias)))))
    .sort((a, b) => b.length - a.length);
  const appearanceGroup = (term) => {
    const g = APPEARANCE_ALIASES.find(group => group.some(alias => normFind(alias) === term));
    return g ? Array.from(new Set(g.map(normFind))) : [term];
  };
  // English multiword descriptors ("blue hair") are kept together, so "blue
  // eyes, red hair" does not accidentally satisfy a search for "blue hair".
  function appearanceTerms(raw) {
    let query = normFind(asText(raw, 140)).replace(/黑長直/g, ' 黑髮 長髮 直髮 ');
    // Use longest-prefix matching, so 白色頭髮 stays a single descriptor
    // instead of becoming the unrelated 白色 + 頭髮 query.
    const fragments = [];
    for (const part of query.split(/[\s,，、;；/]+/).filter(Boolean)) {
      let cursor = 0;
      while (cursor < part.length) {
        const match = appearanceCN.find(alias => part.startsWith(alias, cursor));
        if (match) { fragments.push(match); cursor += match.length; continue; }
        const start = cursor++;
        while (cursor < part.length && !appearanceCN.some(alias => part.startsWith(alias, cursor))) cursor++;
        fragments.push(part.slice(start, cursor));
      }
    }
    const tokens = [];
    for (let i = 0; i < fragments.length && tokens.length < 12;) {
      const phrase = appearanceEnglish.find(p => {
        const parts = p.split(' ');
        return parts.length > 1 && fragments.slice(i, i + parts.length).join(' ') === p;
      });
      if (phrase) { tokens.push(phrase); i += phrase.split(' ').length; }
      else { tokens.push(fragments[i]); i++; }
    }
    return tokens;
  }
  // Match English whole tokens, not substrings of unrelated names (e.g. red != tired).
  function hasAppearanceAlias(haystack, alias) {
    if (!alias) return false;
    if (/[\u3400-\u9fff]/.test(alias)) return haystack.includes(alias);
    const escaped = alias.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp('(?:^|[^a-z0-9])' + escaped + '(?=$|[^a-z0-9])').test(haystack);
  }
  function searchCharacters(query, offset = 0, limit = 80) {
    const list = db();
    const tokens = appearanceTerms(query);
    const selected = currentCharacter();
    if (!tokens.length) return {total:0, databaseTotal:list.length, list:[], selected};
    const groups = tokens.map(appearanceGroup);
    const foundCharacters = [];
    const seen = new Set();
    for (const role of list) {
      if (!role || !role.char) continue;
      const char = asText(role.char, 256), series = asText(role.series, 256);
      const key = normFind(char) + '\x00' + normFind(series);
      if (seen.has(key)) continue;
      seen.add(key);
      const cn = asText(Array.isArray(role.cn) ? role.cn.join(' / ') : role.cn, 350);
      const seriesCN = asText(role.seriesCN || '', 200);
      const identity = normFind([char, series, cn, seriesCN].join(' '));
      const rawAppearance = Array.isArray(role.appearance) ? role.appearance : [];
      const appearance = rawAppearance.filter(x => typeof x === 'string' && x.trim())
        .map(x => asText(x, 200));
      const normalized = appearance.map(normFind);
      const matchingTags = [];
      let matchedIdentity = 0;
      let matchedAppearance = 0;
      const allMatched = groups.every(group => {
        const nameHit = group.some(alias => hasAppearanceAlias(identity, alias));
        const tagHits = appearance.filter((tag, i) => group.some(alias => hasAppearanceAlias(normalized[i], alias)));
        if (nameHit) matchedIdentity++;
        if (tagHits.length) {
          matchedAppearance++;
          tagHits.forEach(tag => {if (!matchingTags.includes(tag)) matchingTags.push(tag);});
        }
        return nameHit || tagHits.length > 0;
      });
      if (!allMatched) continue;
      const exact = tokens.some(term => identity === term) ? 10 : 0;
      foundCharacters.push({char,series,cn:asText(Array.isArray(role.cn) ? (role.cn[0] || '') : (role.cn || ''),256),
        seriesCN, preview:asText((matchingTags.length ? matchingTags : appearance.slice(0,4)).slice(0,6).join(', '), 440),
        rank: exact + matchedIdentity*4 + matchedAppearance*3});
    }
    foundCharacters.sort((a,b) => b.rank-a.rank || a.series.localeCompare(b.series) || a.char.localeCompare(b.char));
    const start = Math.max(0,Math.min(100000,Number(offset)||0));
    const pageSize = Math.max(1,Math.min(100,Number(limit)||80));
    return {total:foundCharacters.length,databaseTotal:list.length,
      list:foundCharacters.slice(start,start+pageSize).map(({rank,...x})=>x),selected,offset:start};
  }
  const handlers = {
    status: () => status(),
    setPrompt: ({ text }) => ({ prompt: setValue(text), result: pendingResult }),
    optimize: async () => {
      const optimize = found('提示詞優化', window.simpleOptimize || window.optimizePrompt);
      const before = value();
      await Promise.resolve(optimize());
      await new Promise(r => setTimeout(r, 160));
      const after = value();
      pendingResult = result() || (after !== before ? after : '');
      return { prompt: after, result: pendingResult, changed: before !== after };
    },
    apply: async () => {
      if (!pendingResult) return { prompt: value(), result: '', message: '尚無新的優化結果。' };
      // The source document decides how an optimization result is applied.
      await Promise.resolve(found('套用優化結果', window.applyOptimizedPromptFloat)());
      return { prompt: value(), result: pendingResult };
    },
    clear: async () => {
      await Promise.resolve(found('清除提示詞', window.clearPrompt)());
      pendingResult = '';
      return { prompt: value(), result: '' };
    },
    characters: ({ query, offset, limit }) => searchCharacters(query, offset, limit),
    chooseCharacter: ({ char, series }) => {
      const item = db().find(x => x && x.char === char && String(x.series || '') === String(series || ''));
      if (!item) throw new Error('這名角色不在目前綁定的 cos_db.json。');
      found('角色選擇', window.selectCosplayer)(item);
      selectedCharacter = { char: item.char, series: item.series || '' };
      return { selected: currentCharacter() };
    },
    applyLook: async () => {
      const selected = currentCharacter();
      if (!selected.char) throw new Error('請先選擇角色。');
      await Promise.resolve(found('角色外觀套用', window.simpleApplyLook)());
      pendingResult = '';
      return { prompt: value(), selected: currentCharacter() };
    },
    searchOutfits: ({ query, offset, limit }) => searchOutfits(query, offset, limit),
    outfits: () => {
      const selected = currentCharacter();
      if (!selected.char) return { list: [], selected };
      const fn = found('服飾資料', window.getCharacterOutfitSets);
      const sets = fn(selected.char, selected.series) || [];
      return { selected, list: Array.isArray(sets) ? sets.slice(0, 120).map((s, i) => ({
        index: i, name: asText(s.name || s.label || '未命名', 150),
        preview: Array.isArray(s.tags) ? asText(s.tags.join(', '), 600) : ''
      })) : [] };
    },
    applyOutfit: async ({ index, char, series, expectedName }) => {
      let selected = currentCharacter();
      const requestedChar = asText(char, 256).trim();
      const requestedSeries = asText(series, 256).trim();
      const changing = requestedChar && (selected.char !== requestedChar || selected.series !== requestedSeries);
      const item = changing ? db().find(x => x && x.char === requestedChar && String(x.series || '') === requestedSeries) : null;
      if (changing && !item) throw new Error('搜尋結果中的角色已不在目前資料庫，請重新搜尋。');
      const target = item ? {char: item.char, series: item.series || ''} : selected;
      if (!target.char) throw new Error('請先選擇角色，或從服飾搜尋結果直接套用。');
      const resolveSets = found('服飾資料', window.getCharacterOutfitSets);
      const i = Number(index);
      let sets = resolveSets(target.char, target.series) || [];
      if (!Number.isInteger(i) || i < 0 || i >= sets.length) throw new Error('所選服飾在目前資料庫中不存在，請重新搜尋。');
      const expected = expectedName ? String(expectedName) : '';
      if (expected && String(sets[i].name || sets[i].label || '未命名') !== expected) {
        throw new Error('服飾資料已更新，請重新搜尋後再套用，避免套錯服裝。');
      }
      if (changing) {
        // Validate the outfit before switching characters: a stale search must not change selection.
        found('角色選擇', window.selectCosplayer)(item);
        selectedCharacter = { char: item.char, series: item.series || '' };
        selected = currentCharacter();
        sets = resolveSets(selected.char, selected.series) || [];
        if (i >= sets.length || (expected && String(sets[i].name || sets[i].label || '未命名') !== expected)) {
          throw new Error('切換角色後服飾列表已變更，請重新搜尋。');
        }
      }
      const outfit = sets[i];
      await Promise.resolve(found('服飾套用', window.applyCharacterOutfit)(
        selected.char, selected.series, i, outfit.tags || [], outfit.name || outfit.label || ''
      ));
      pendingResult = '';
      return { prompt: value(), selected: currentCharacter(), outfit: asText(outfit.name || outfit.label || '服飾', 150) };
    }
  };
  window.__comfyPetBoundBridgeV1 = Object.freeze({
    dispatch: async function (action, args) {
      try {
        if (!Object.prototype.hasOwnProperty.call(handlers, action)) throw new Error('不支援的 PET 操作：' + action);
        return { ok: true, data: await handlers[action](args || {}) };
      } catch (err) {
        console.error('[ComfyUI PET bridge]', err);
        return { ok: false, error: err && err.message ? String(err.message) : String(err) };
      }
    }
  });
  return 'ready';
})()
