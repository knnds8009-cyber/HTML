/* ComfyUI PET v2.4: File System Access compatibility adapter.
 * The user's bound HTML remains untouched, including its JSON conflict rules.
 * This runs only in the HTML engine window, never in the PET button window.
 */
(() => {
  'use strict';
  if (window.__comfyPetNativeFsV2 || !window.__petNativeFS) return 'unavailable';
  const native = window.__petNativeFS;
  const createError = (name, message) => new DOMException(message || name, name);
  const encode = async (data) => {
    if (typeof data === 'string') return new TextEncoder().encode(data);
    if (data instanceof Blob) return new Uint8Array(await data.arrayBuffer());
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    throw new TypeError('Unsupported file write data type');
  };
  const folderPath = (parts) => parts.join('/');
  class NativeFileHandle {
    constructor(token, parts) { this.kind = 'file'; this.name = parts[parts.length - 1]; this._token=token; this._parts=parts; }
    async getFile() {
      const response = await native.read(this._token, folderPath(this._parts));
      return new File([response.bytes], this.name, {type: this.name.toLowerCase().endsWith('.json') ? 'application/json' : '', lastModified: response.mtime});
    }
    async createWritable() {
      const file = this;
      let current = new Uint8Array(0), position=0, closed=false;
      const grow = size => { if(size>current.length){const next=new Uint8Array(size);next.set(current);current=next;} };
      return {
        async write(value) {
          if (closed) throw createError('InvalidStateError','File is closed');
          if (value && typeof value==='object' && 'type' in value) {
            if (value.type==='seek') {position=Number(value.position);if(!Number.isSafeInteger(position)||position<0)throw new TypeError('Invalid seek');return;}
            if (value.type==='truncate') {const n=Number(value.size);if(!Number.isSafeInteger(n)||n<0)throw new TypeError('Invalid truncate');const copy=current.slice(0,n);current=new Uint8Array(n);current.set(copy);position=Math.min(position,n);return;}
            if (value.type==='write') {if(value.position!==undefined)position=Number(value.position);value=value.data;}
            else throw new TypeError('Unknown write type');
          }
          if (!Number.isSafeInteger(position)||position<0) throw new TypeError('Invalid write position');
          const bytes=await encode(value);
          grow(position+bytes.length);current.set(bytes,position);position+=bytes.length;
        },
        async seek(n) {if(closed)throw createError('InvalidStateError'); n=Number(n);if(!Number.isSafeInteger(n)||n<0)throw new TypeError('Invalid seek');position=n;},
        async truncate(n){if(closed)throw createError('InvalidStateError');n=Number(n);if(!Number.isSafeInteger(n)||n<0)throw new TypeError('Invalid truncate');const copy=current.slice(0,n);current=new Uint8Array(n);current.set(copy);position=Math.min(position,n);},
        async close() {if(closed)return;await native.write(file._token,folderPath(file._parts),current);closed=true;},
        async abort(){closed=true;current=new Uint8Array(0);}
      };
    }
    async queryPermission(opts){return 'granted';}
    async requestPermission(opts){return 'granted';}
    async isSameEntry(other){return !!other && other.kind==='file' && other._token===this._token && folderPath(other._parts)===folderPath(this._parts);}
  }
  class NativeDirectoryHandle {
    constructor(token, parts, name){this.kind='directory';this.name=name || parts[parts.length-1] || '資料夾';this._token=token;this._parts=parts;}
    async getFileHandle(name, opts={}){
      const segments=this._parts.concat([String(name)]);
      await native.inspect(this._token,folderPath(segments),!!opts.create,'file');
      return new NativeFileHandle(this._token,segments);
    }
    async getDirectoryHandle(name,opts={}){
      const segments=this._parts.concat([String(name)]);
      await native.inspect(this._token,folderPath(segments),!!opts.create,'directory');
      return new NativeDirectoryHandle(this._token,segments,String(name));
    }
    async *entries(){
      const values=await native.enumerate(this._token,folderPath(this._parts));
      for(const x of values){
        const seg=this._parts.concat(x.name);
        yield [x.name,x.kind==='directory'?new NativeDirectoryHandle(this._token,seg,x.name):new NativeFileHandle(this._token,seg)];
      }
    }
    async *values(){for await(const [,v] of this.entries())yield v;}
    async *keys(){for await(const [k] of this.entries())yield k;}
    [Symbol.asyncIterator](){return this.entries();}
    async removeEntry(name,opts={}){await native.remove(this._token,folderPath(this._parts.concat(String(name))),!!opts.recursive);}
    async resolve(child){if(!child||child._token!==this._token)return null;const a=folderPath(this._parts),b=folderPath(child._parts);if(a&&!b.startsWith(a+'/'))return null;return child._parts.slice(this._parts.length);}
    async queryPermission(opts){return 'granted';}
    async requestPermission(opts){return 'granted';}
    async isSameEntry(other){return !!other && other.kind==='directory' && other._token===this._token && folderPath(other._parts)===folderPath(this._parts);}
  }
  const makeRoot = r => new NativeDirectoryHandle(r.token,[],r.name);
  const picker = async (options={}) => makeRoot(await native.select(options?.mode || 'read'));
  // Prefer the native picker over Chromium's file:// grant handling. In the
  // original HTML, the existing button calls this method directly.
  try {
    Object.defineProperty(window,'showDirectoryPicker',{value:picker,writable:true,configurable:true});
  } catch (e) { window.showDirectoryPicker = picker; }
  if (window.showDirectoryPicker !== picker) throw new Error('Cannot install PET native folder picker');
  const restore = async () => {
    const previous=await native.remembered();
    if(!previous)return {ok:false,message:'尚未指定資料夾'};
    const fn=window.__selectDataFolderImpl || window.selectDataFolder;
    if(typeof fn!=='function') return {ok:false,message:'HTML 資料夾模組尚未載入'};
    const original=window.showDirectoryPicker;
    try {
      window.showDirectoryPicker = async () => makeRoot(previous);
      await Promise.resolve(fn());
      return {ok:true,name:previous.name};
    } finally {window.showDirectoryPicker=original;}
  };
  // A plain JS folder handle is intentionally not structured-cloneable into
  // IndexedDB. PET itself remembers the authorized native path and reattaches
  // the same folder after reload, using the original HTML's selectDataFolder.
  // The source HTML's existing Unbind button must also clear PET's persisted
  // folder, otherwise the next PET launch could silently reconnect it.
  const clearFn=window.clearDataFolderBind;
  if(typeof clearFn==='function') window.clearDataFolderBind=async function(...args) {
    const ret=await clearFn.apply(this,args);await native.forget();return ret;
  };
  window.__comfyPetNativeFsV2 = Object.freeze({restore,selectFolder:()=>window.selectDataFolder?.(),forget:()=>native.forget()});
  return 'ready';
})();
