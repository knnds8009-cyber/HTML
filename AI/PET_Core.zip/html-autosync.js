'use strict';
// PET HTML AutoBind v2.8. No prompt, JSON or character processing belongs here.
// Find the highest complete release, update ONE stable HTML file, never edit releases.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const BASENAME = 'ComfyUI_PNG_Prompt_Viewer.html';
const RELEASE = /^ComfyUI_PNG_Prompt_Viewer_v(\d+(?:\.\d+)*)([A-Za-z]{0,5})(?:\s*\(\d+\))?\.html?$/i;
const STABLE = /^ComfyUI_PNG_Prompt_Viewer\.html?$/i;
const MARKER = /<meta\s+name=["']comfyui-autosync-version["']\s+content=["'](v[\d.a-z]+)["'][^>]*>/i;
function parseVersion(filename) {
  const m = RELEASE.exec(String(filename || ''));
  if (!m) return null;
  return {version:'v' + m[1] + m[2].toUpperCase(), parts:m[1].split('.').map(Number), suffix:m[2].toUpperCase()};
}
function compareVersions(a,b) {
  const n=Math.max(a.parts.length,b.parts.length);
  for (let i=0;i<n;i++) {const d=(a.parts[i]||0)-(b.parts[i]||0);if(d) return Math.sign(d);}
  function rank(s) {let x=0;for(const c of s) x=x*26+c.charCodeAt(0)-64;return x;}
  return Math.sign(rank(a.suffix)-rank(b.suffix));
}
function versionText(text) {
  const m=MARKER.exec(text);
  if (m) return parseVersion('ComfyUI_PNG_Prompt_Viewer_'+m[1]+'.html');
  const t=/<title[^>]*>[^<]*?\s(v\d+(?:\.\d+)*[A-Za-z]*)\s*<\/title>/i.exec(text);
  return t && parseVersion('ComfyUI_PNG_Prompt_Viewer_'+t[1]+'.html') || null;
}
function readSafe(filename) {return fs.readFileSync(filename,'utf8');}
function checkHtml(text) {
  if(text.length<100000 || !/<html\b/i.test(text) || !/id=["']promptInput["']/i.test(text) || !/id=["']appVersion["']/i.test(text)) throw Error('HTML 缺少必要的提示詞／版本元素或內容不完整');
  const scripts=[...text.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi)];
  if(scripts.length < 5) throw Error('HTML 腳本不完整');
  for(let i=0;i<scripts.length;i++) if(scripts[i][1].trim()) new vm.Script(scripts[i][1], {filename:'html-script-'+i+'.js'});
}
function normalizeHeader(raw,ver,hash) {
  let result=raw;
  const title=/(<title[^>]*>)([^<]*?)(<\/title>)/i;
  if(!title.test(result)) throw Error('缺少 HTML 視窗標題');
  result=result.replace(title,(_m,open,text,close)=>open+text.replace(/\s+v\d+(?:\.\d+)*[a-z]*\s*$/i,'').trim()+' '+ver+close);
  const heading=/(<h1\b[^>]*>[\s\S]{0,400}?<span\b[^>]*>)(v\d+(?:\.\d+)*[A-Za-z]*)/i;
  if(!heading.test(result)) throw Error('缺少頁內版本標題');
  result=result.replace(heading,(_m,prefix)=>prefix+ver);
  const build=/(<span\b[^>]*\bid\s*=\s*["']appVersion["'][^>]*>)([\s\S]*?)(<\/span>)/i;
  if(!build.test(result)) throw Error('缺少 Build 顯示欄位');
  result=result.replace(build,(_m,open,old,close)=>{
    const date=/\b\d{4}-\d{2}-\d{2}\b/.exec(old);
    return open+'build '+(date ? date[0]+'-' : '')+ver+close;
  });
  const marker=`<meta name="comfyui-autosync-version" content="${ver}">`;
  const hashMarker=`<meta name="comfyui-autosync-source-sha256" content="${hash}">`;
  result=result.replace(/<meta\s+name=["']comfyui-autosync-version["'][^>]*>\s*/gi,'')
    .replace(/<meta\s+name=["']comfyui-autosync-source-sha256["'][^>]*>\s*/gi,'')
    .replace(/(<\/title>)/i,`$1\n  ${marker}\n  ${hashMarker}`);
  return result;
}
function findFolder(selectedPath, fallbackDir, envDir) {
  const candidates=[envDir,selectedPath&&path.dirname(path.resolve(selectedPath)),
    process.platform==='win32' ? 'F:\\HTML' : '',fallbackDir];
  let firstExisting=null;
  for(const c of candidates){
    if(!c)continue;
    try {
      if(!fs.statSync(c).isDirectory())continue;
      const dir=path.resolve(c);
      if(!firstExisting)firstExisting=dir;
      if(fs.existsSync(path.join(dir,BASENAME)) || fs.readdirSync(dir).some(n=>RELEASE.test(n))) return dir;
    } catch(_){}
  }
  return firstExisting;
}
function listReleases(folder) {
  const releases=[];
  for(const ent of fs.readdirSync(folder,{withFileTypes:true})) {
    if(!ent.isFile())continue;
    const version=parseVersion(ent.name);
    if(!version)continue;
    const filename=path.join(folder,ent.name);
    const stat=fs.statSync(filename);
    // Invalid or partial releases are reported and skipped by checkHtml below.
    releases.push({filename,name:ent.name,version,mtime:stat.mtimeMs});
  }
  releases.sort((a,b)=>compareVersions(b.version,a.version)||b.mtime-a.mtime||b.name.localeCompare(a.name));
  return releases;
}
function atomicWrite(dest,txt) {
  const tmp=dest+'.sync-'+process.pid+'-'+crypto.randomBytes(5).toString('hex')+'.tmp';
  try{fs.writeFileSync(tmp,txt,'utf8');fs.renameSync(tmp,dest);}finally{try{if(fs.existsSync(tmp))fs.unlinkSync(tmp);}catch(_){}}
}
function refresh({selectedPath='',fallbackDir='',envDir=''}={}) {
  const folder=findFolder(selectedPath,fallbackDir,envDir);
  if(!folder)return {ok:false,error:'找不到 HTML 所在資料夾，請指定資料夾或選擇 HTML'};
  const stable=path.join(folder,BASENAME), skipped=[];
  let releases=[];
  try {releases=listReleases(folder);} catch(e) {return {ok:false,error:'無法掃描 HTML 目錄：'+e.message};}
  let chosen=null, normalized='';
  for(const entry of releases){
    try{
      const src=readSafe(entry.filename);checkHtml(src);
      const hash=crypto.createHash('sha256').update(src).digest('hex');
      normalized=normalizeHeader(src,entry.version.version,hash);
      checkHtml(normalized); chosen=entry;break;
    }catch(e){skipped.push(entry.name+': '+e.message);}
  }
  let previous='', oldVersion=null;
  if(fs.existsSync(stable)) {
    try{previous=readSafe(stable);oldVersion=versionText(previous);}catch(e){skipped.push('現有固定入口無法讀取：'+e.message);}
  }
  if(!chosen) {
    if(previous){try{checkHtml(previous);return {ok:true,path:stable,version:oldVersion?.version||'未知',sourcePath:stable,updated:false,skipped};}catch(_){}}
    const selected=selectedPath&&path.resolve(selectedPath);
    if(selected && fs.existsSync(selected)){
      try{checkHtml(readSafe(selected));return {ok:true,path:selected,version:parseVersion(path.basename(selected))?.version||'未知',sourcePath:selected,updated:false,skipped};}catch(_){}
    }
    return {ok:false,error:'找不到可用的版本化 HTML（或現有固定入口）',skipped};
  }
  if(oldVersion && compareVersions(oldVersion,chosen.version)>0){
    try {checkHtml(previous);return {ok:true,path:stable,version:oldVersion.version,sourcePath:stable,updated:false,skipped,notice:'保留已安裝的較新版本，不自動降版'};}catch(_){}
  }
  const updated=previous!==normalized;
  let backupPath='';
  if(updated){
    try {
      if(previous){
        const isAuto=MARKER.test(previous);
        backupPath=path.join(folder,isAuto?'ComfyUI_PNG_Prompt_Viewer.previous.html':'ComfyUI_PNG_Prompt_Viewer.manual-backup.html');
        if(isAuto||!fs.existsSync(backupPath))fs.copyFileSync(stable,backupPath);
      }
      atomicWrite(stable,normalized);
    }catch(e){return {ok:false,error:'無法更新固定 HTML：'+e.message,skipped};}
  }
  return {ok:true,path:stable,version:chosen.version.version,sourcePath:chosen.filename,updated,backupPath,skipped};
}
function restore(sync){
  if(!sync?.updated||!sync.path)return false;
  if(sync.backupPath && fs.existsSync(sync.backupPath)){
    atomicWrite(sync.path,readSafe(sync.backupPath));return true;
  }
  // Do not remove an original hand-authored stable file; no backup means we created it.
  if(!sync.backupPath && fs.existsSync(sync.path)){fs.unlinkSync(sync.path);return true;}
  return false;
}
module.exports={BASENAME,parseVersion,compareVersions,normalizeHeader,checkHtml,listReleases,refresh,restore,STABLE};
