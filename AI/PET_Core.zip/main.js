'use strict';
/**
 * Windows transparent PET shell. This program does not contain prompt rules,
 * character data, outfit data, or JSON loading logic. A selected HTML file
 * runs, unchanged, in a persistent hidden (or optionally visible) engine window.
 * Every domain action is forwarded to that actual page's functions.
 */
const { app, BrowserWindow, ipcMain, dialog, screen, clipboard, session, shell } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const nodeOS = require('node:os');
const htmlAutoSync = require('./html-autosync.js'); // v2.8 PET owns automatic HTML rebinding

// v2.2: PET's own control resources are embedded in main.js as a recovery copy.
// This is UI and IPC glue only. Prompt/JSON/character algorithms stay in the HTML selected by the user.
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const UI_FALLBACK_BUNDLE = {"control.html":"eNqtWV9z09gVf99PcauZDi8Vsez8Y9f2TJvpDnTiwhTKuyJfx9rIklaSvYQnZyFNAgnOFggbYkhTQsjCJmRZsmTBgZn2m7CRbD/lK/RcHUmWHDuYlEnG9r0699xzfuffvUfJ32U1yZrUKclbBSX9WZJ9EUVUx1Pc1Tx/VlQtjs1SMQtfBWqJRMqLhkmtFFe0cvwwR/r8B6pYoCmuJNNvdM2wOCJpqkVVIPxGzlr5VJaWZIny7uAPsipbsqjwpiQqNCWEuOQtS+fp10W5lOJGkAN/kUpFQ7Ym+QuaIkuTIdZZmhOLisWbhkROmVTJnSJZ0RI//4KY1qRCw/Oniqop5igvq4qs0lNAIRmyHl76BZEL4x1YaWNfUckjVDVYi+JasqXQ9IhWyE3+/Ry58OdLyT6c+iwJO0wQgyopzhXDzFMKgOQNmktxTHZDU05Lpol8+jx0x7TsJHxl5RKRsylOp9bFPFUU0FYRTdOd4E2cYYLxmk7VFJcTFZOCjQhxV3q0WYBSVnhdVCmQM3Y4c8GdYNRRepeQZ4JQg0sffcJsC/MmjPwHpiVaRZNXaBY3wPEoDNPJPkbokbu6MCaXGDhc+oKhFXQL8UKyPtgunRwrWpaG5JKmKKIOavl7McF4UbJkTeUIc9cUh+QwYlxTnHPnF3txtvng386Dd1z6v/eSfUjgce+oMBfIxtOsbHmwHKXjJ2RpguHiVBbr668bPzxs1Pbs6cekpSALihGtCF4JZDFib92zp69F9PN5W/SKJRpUxL1dLC7BFEdMHUwr5ak04RuV6Ioo0bymgFFSnF3dbJaXG4/W6isvnVuPUQRndqnxonawd4MgrO/LGwx+f5OuGiGWJhfAHgWVycYg0YzzuiUX5KstU+iGXBCNSS79vrpB7OtP7fmlFtYfYPZHXVfclbeJ/fhe/c5mzytHNB0WNtZnGo/2O5k2qqJBTZYUmNdwaZSxvrvoPKyCxQqioriMkWhUHGMBYe/cr19fQyIwGyPqwL61DE0W3Y6BDj4yP0cYNAf770DB+i9T9vZ9cvZSZpTU719HWeyZfbtW+a38bdg3e3LTgmbAMC9ns1T9oLfa7541y6v2jdXGtf2uUBWoWuQRz2O9gSWbEXBycBzGu/Hkn425F/b6UuNJGcMg/b78OnD4D1qVsTsPBYRFHfJyqgvNR29PyusitSxZHQcVIK+QxuYWoH5Yq4Th7865GzaqZkHFCpSt3EAZ0XWd6jUMRPu7ml15Vl/ZtucW2s19a9Wpzp3c3FIAeK82j9rFg8wnVERZ5Vlpwi3GRGmiZdIosOnGuzv2ysMuGMmqXrSCvOeuv0hFQ8oHIWF6Q2TqRkZbNltcqG/+BCY62K/at6fgBwp9WLvfnPmu+Wz7t/JU/eV0vVqDH82V5ebGj/bOW5beiFi0NAmSnUIt4K3lcm4ZbQvTNsHOqTmtTTjeLBYwkzmLVXvnpgedKxfsiXJBfkW56nO/2m93D2srzXvV5sIuS/CV5/Xd61B0opaNGkfKayb1/DQQaQQnWdJxqk+bU3vO7RncvSsfOKtATeRlixbMNm6jsglBlNSPeK1bIMJatSnTXLppP7mJyrs66G1mDlfkYDdNzGbcLORtp8CEl5eioel5bHPtOdRMZ+WlvX7fV9Jzqg77iKxCjGraRHu9IWPyeOcTQBrjMez50R16izUNs9HHBZqftD4caF6yO1mUoWzHhpg/igRZfWGz/syzMIoK4eU8v2OvvrZ3WGDVl/dBC/jh/GsNCLqFl2jIIq+wSgkHLZdPEAXI/LA223jlmeCwNtcpIMM6HBuN6LdtG9jTm2HEIQ7rP7wG6Z3lb9HBMP8iDWReJOs1MlE2PyzDrACvcJT2FJ/EEhUlzLhbhIYNE+Sd5loF9m3Mzjiby/Wf1g9r8wd7C81qubExZU/Pghgo2IcC1tv5/4lWFOwksWT61bjXaGoV7V5iKSj2HxNNYWN56/lxQyvqwbEfiFwf98lyMlWy6Pa+U2B9B/9yS3yyz30YWu87+xhcBbIXRKsVrToMvBNiY7tsV5YO9rYg3CIytjO4TA3TzXfd6tbWI7gU2FO7zt6PTrXsLO3U52Zdybpwjup/9NiHmV6DMDhrFZQjR/42uDEkoHI3ZxbY3q2zz5FDGx6cmfMh4zZG7vpGbQ7ivrP12nwbDnxfFkM34xwM+OBCGOUNRe7uqjNXDkxnb887d19G5ewIkx+mrnPOzuA6QBhP9vYiBGb54M2+ywnCtPHzjLO0bK+/Pfh1lZ0N8HBY3XS21tG127NRdLewt2HzAg7nojEO3m9p+udCXL/Cpf9y8fxfSbARZF0mW7P8CHaCtHusM33p1oRuPolJDjE6Bnl0DmTVnkE62KLlIpBRnMoKicp/5CDQa8B2j1OS06DumXBh/ZuojoPx7FeP7elX9uw9e/2JvVMhSUiMflllZJdFpQhkQiz2+2QfPkv7ce1VYFTTcPmRgqymuKEY/BCvpDghEWPGonqKG+BIifGCyViMC/ijGFAPP5lymi5KsjXp6ceKQ7nifH/Lfr3BqvAvNw72b8EnToJTRDT21p5I6f4BX+nYcUpHxDui99FT6sxT++ZdTIkQUoFvRPMZVkG7sgHnO/v6C3vre+80MLuEVQrXeUXxuEo1poHHFXhsVqHEBWqaIhMWSjj1+1j+oUcuwZSuKVDZ/YSLwkZLQTjhtn6oYincvDNEWWk7TK3Ns5bVzJ6zux14aof2XNYQIV2LRqvdNT93sF9xbi45Kz8fvHlcf/IGUGQ9NS79n1fsL6x+x5uz37tgbcIxSyXsbF2iRJHH8xbiwh6dY84QldlrPK39IxAGZ1iUu0041icsjRPWCP6TBv4SIzES74d/dgaClEMY5kKcCGfIED9EEiQBn0N8PxGuZoRhIiSUOB8X4yRO2MoYn+ATCg/DTILEhfwgx3wKNki3nUzC/R+mFIxl7GZ+LBRZ0ZhoQdDqgIVRwE5OAIG9+qqxNt+x29MrHAkinB4gg/AH37z7OcpQGlZ4d2K0Hx4LsdMDyiCbAKzOkESpPyMMkYF8fwbgGy4lMnFGdOb0QD7RDaeeIDBldgFogYCduygC7rWrhYA7DDfbelIcxI6TATIwGo+RwU8qstsyjHqu2z5sua07DHq6rAXRo/QGlSwCc8McmXQ/8Q0HJ8ThxEtZBOFvA2jiTClf3YwwSIYvD4acG1z9bGRM4qXh1hi+4/n4p8VFoSyRRNLQ3jRcp1rJZW+6ubweANOLHcH9hvLCYEaIEUEoDWWEfvweJEOKQIT+vBBTBF7oz0DMX+7PD5YSHxnGBBP3CaIZbzu+9ngbiijvXnawTdryDe/2V/Hvm14r8TgsJNmQFEqkK25dlCY9H4Cv0/1M29Bz9uB4gjOdCD7WB74uyl4ux19htZmXP1h1S4avNLtzL81hFQm9QXFLGpQy9qrKxT6Jb86IaUit11lfme57H/cJo/TeZvXhe8X/AQIAOxs=","control.css":"eNqlWVuPozgWfq9f4Z1Sq6dakMEEEgKaeWmttLM3rTSz2odWPxgwiacIZMGpy7T6v+85tgEbqKpejUopBWMfn8t3vnPspF3bSo+c5Ln2SN6Wz+QLObPuKJo0+JM4X9pOskZm5MLKUjRHdzBvu5J3szFW3B+79tqUqexY019Yxxtpz2gfeFfV7WN6EmXJm4x8vUlRC9i5aOu28/vixM88LVl3n5GqbaRfsbOon9P3v/Bjy8m/f37vvf+HKLq2bytJ/nrizfEvXMDgP1vZkl9gV/Lrx/de/9xLfvavwuthyO95Jyrc7QPslLdPfi9+R5O0FT6M4Evjg0dRylNKg+DhMSMnLo4nqZ5OmVYyveUJz6sgI1eQC7JrXsi0aRuuhFylbBtP8icJ5jNPNJcr2ofGpKI5gSZymoeGX7sehF5a0UjeZcR/5Pm9kD67XPyOH0XbgGy/7NhxWpZWbXHt/QfRi7zmeo/Z2KCAOwz7tVdZi4an4eWJ9G0tSnLL4jyqimx45bdV1XOJM3DLTzpYn2FtKfpLzZ6VsXZcv95sLlz6/YnXNUy7tL2QqHjHaybFA5/70XHx27Ax4jsmHOksB/2vEqR3SniC+sr2or/kLXjqrL/r/fahHlcx71gprn0aBWpsUgEdwDr/iO9Bje9pHJT86HXHnH1Pg71HKYXPwdsc9nd6NAq8iHrRDoaSOxLt3g2TA48GIXwSeBPf3Y1JQ0fPq4khCAijED4gYhuoeYDQEyshUQJCQUMSRvBPzQ48/NtE4Z1HRANhIigOP+EwJYxjb/hs6B4EDnGrav6UsVocG19AfvRpwRXocNwvRQdARscCzK/nZsr8A0jeoZ+OzDgXIoKI9HPWjRkTb/GNCTQqDMEAEPpqv2EnogA2TFIrVJo/6pFDAGlVcykxsS6swN3BBH6ecq/kZUWzIW3OLaJrJWeGhNkgavxcNpOesaWnfkD7wdUB0Y8Duc3BEgfvXoLrqF+VVAxzaXD5sRNlBt8K7rqcqMUayJNIsqFxTzjruafkTc+OLekJmRS5bFJmJfTxnbNqwwpMxoECB4AhbvYzeNFktrRGb7kb3vI9EuFoeRiGccjcZUjks1V0R/d0WlVV1XLJmn234SHMt6Eb0/7hOMY1tOOqHypR14aZe9m19zwF2GC4PuLmw6Bv6GiTjCOI0gLArrbOrMHfgKbN6EKRQnSFolizl95Y6eBuOywsxYMo+ZRB0c6ygM6IaRnfcAdBMhUbCSBYSN5oEhwLu4/syK6ydV1+bjs+zTHEqaX99yrk5OFk6eEhc8J55ryeJkVc7IvKJD9UY27IwKYHupp/RqkRIjaOXk+HrcZ0ySUafmENf6GcoJdoZBUR/WCqzGGqKAWrCyT6d8QHngYD7uYqh1bNWRA/BeKney/cUggmavdaHYrisQ6FibcNPSgbWHFMtYk9mkAJUUOLEoIpvt3NcjyO7lY6MqdUkBcKg13vP5VMMr+98ObH7ypW9/y7z2TuY7tv0KvxBcSZafi/VZ9+u/ZSVM9+AWiBkRRLA/dzLh856IxVCYMylCuMFqEx/kPvj02eDuUsBjZCgsOdpV3Dztw0bkN52kN5mhBLEbGO6oMmKyacIbM0aILs8QSvVH1Dknjs2CWbx0FVznEQ3CwuveiVdr1kEjq6mpeW50SjMiev2+I+M+0OKGIyaT+5wUolm1zLbZInVDcC/akTzb0hgGm3TTun8t2hLBnPHKwFZMQZDcCvIbRLe4BlpF2LIfeZQtNb5SuAzmUo+gGPOM9eSKN5CF1LMR6GvnaTR9R3pxdBqFhsFJg2B7GALOFgaztSH3AURtYICb4xfxAn1N7BvxfFvUoFC16jRgZ9uzjIJvqsSp79sbyBzW+LE+s+QgDkfHNVfsxuh4ht88TRJQoUPMZjzqYHtipO5IuNj6CAbvkwBnEHnVuyDOLtdh+FMZ2FTSkweh1dMRxcFInYRy9UIhtawMWLSUn7bPduAAKNsKh1XFmtRM8i4FSkzc62Wp+tBtv1k+qulCHG7H2U7NluirQGf2/lrmoR8Z8PsYMR4AYNFPDCJqw6QvVH0Utso2aQZQ6doIiU4C9fP0/j1bWu/eEhF0crAxfRiLYx3W1XksjpxfbbbbQdIxtDZA+ZfVyInWxSjlxhvfFAu7l0AtqP53mHmcAfG7ahBeVhtAIgXnBeRdmcqRfSV9vKMioLPFBgQ8T7ay1VWfrDRWlI1LyMOV2k8cw1VncWmfjauvRnps7VQzqGjOaxLSOYMYXJzkEI4hWzWxOWxVf7QG3+NOL7gANj2VGd4kq+xlEANszyNZhBJChpSJkDiknPiWPc9Irj7BHE+jlk132q/vs44IDn0kHLjvBZ5DrarOu8r+vWYDXWJd33Gq1Vi/dWK7AoT17swck/hHPVyEzBUA8st0Zb1627xPKq/2w68DnZup6I4ol+K8aLaGncJkecjv1vHkEthjln3lxHBpjBeL0eOeXIWT7eUjlSXke+wxNRWG7HBAaWCCu2hqgqyuNyjqhw1tPNW68XtB2y3NZjG0GJSRbeAcXBOEssBsoterCkaaUouJV/BWN58TqQd7FJ6nSnr2Y0adcMUAIz7x317APSeIIym7FDDg3hfLPBLdiNoCuwUTMF2CpxM5aBScWp7blrMp1MzvdFXO5tJKtD2bAZdtTJopNM3LxfSSVIlxH8mLcpa54fT7xTaO2LroXipJgV9FpQVGAn0jYKVjLpGxEeGz9ZG26kIlZrB9UBwCx8Tb5Y91c1r9wr7lu6h3I0YruiVQw1cJUtt/FujS0X1PiNhkTaEFRRY91T38frHbf/OFDYhrpZeQCl2GgmXlc0RwcUa63nOjGPQnSNmhWlGbuPoN7lUXF4WaLdolh4tklXQ161O72Phl3Il2/0X+L63nENjWge7tbCGGxZxNbCCIpUgtelX7Oc14vc+j+Yc+gZaFGURaaaPHky1Vv9foD7/QB+JB+Bvdqa9d65bVolZHRtAuZUdtLE0aKmv5COK73zoqX8sjjwxk4wFqXDpPQMGIP/k4nArCZ14UQ7XF9v1O8dn+Tzhf8IzHnknx2UsAIbtAH+ZQKHxyqb/cry9ebmhw/kX3/+lTyEm11KRFPyC4d/jSTHus1ZjT+GVEISTasecP8Z3CyJbqngEc5MHhwLgeKPG/Lhh4GA/f56Np3skIBblhTR6+UCqr3FeXSv68WtavKNIiPBzzsamKen/F30ME1/94HkrJKVH4pDqS9a6xZO4ObGzyGF7TaI9gOMypyzauXEfRvFO7qv3qCzeeVZaDxpsdqTQ7newRmE6DBBiPYpYZcLOIA1UImNJ85Mwn/oBh8EfyRtUz+rOCg62uDBFuIFOuppoysS6Mjz0Gm/gmX7FU9XY7MkmZQ6pASGGgUj0ZOyhSN8SWRL5IkTrBcewWsxImRP9E2YeacuEuEsKk8QLHJuH8Bt+gUTtQbT7HqtFyX/8Tu1Dq/XrF/DcB/9m4y+nhw9/LqE2QWdlnJYirHS5LChKRkol7AGziW6xz4xqDp2BgE9oGGKlzY35AP5jzGVKT8QXYIh6mjz4Gblg7ERKp5JX6vLcYHOw6wtIcQoDFp30lZqbSWeYNhccmttPIDFPcqClMGfEHv9uyd4HthN+9ax/Scyv4xcgnW+4I0jxsrPn7/76J+nNJzSevTklxtijmaEagkw4HRA8DyC8Wm4IbQHTSNkhkyHk3MIjADIY7EBD+Jr/SpnnbmLlKf5uMmSONwF+x2xO1OYZlJ8uEtVl2Q3C4N+IrPK7K3M0E312pvZfdiC7JwFaTpc/IwmjNc8Dou+ssCXp+s5n1GQdsAaz4FISIq/cX4BoHdHPuWEKV6qD+gBbwyRxx+AAjDXAf2qSQKzMKN+b9uzwuPMA8uKa18df31z+lBB3euWDnbOXEH/A6xXwxE=","control.js":"eNqtO2tv21aW3/srboDZkIRVxd3FLgobqtGmKaa7aRo02fnSKRa0dGVxQpMKSdn12AKcadPEE7vOtGmySbzNtk1Sb5pnX2nT2AXmp0xNSf7UvzDn3BfvpShZzg4COBTvveee1z2ve2i1YkriJPKqiTX5nG07pPISWXyOkGoYxAlxmx6pkHkvqIXz5Wo4W184TpNJNfwbGPRquKQWVluzNEjKMzQ54lN8fGXh9Zrt1Zxsetygvg9LfmNbTZqcwF+WNpzQdxMxGoWzzeQk/NbHm25A/RhmvG3RmpdYJWs2jCj8V224kVtNaATPYSups7GYJokXzMTWOwjBpwmptqII8DqOYCoCBKHvAtgarVXqrh/TEpluxQvyGacACP4zw6PmuTNBGCdeFXBRhMsHQX255iYu4FAGSl/VFlQqxHrBIktLJKDz5D/fOnqCulG1cRwomI1tP6y6iRcG5Zi9dcoNN7atbEPODiQmWWgCaie9WRpVgpbvl4jvJjRO3qJxy08qloUv4uRIMOMFFDnJXkmmVBZJ7P2RTrwwPl4Km27VSxbwmbQVrxphTIPKIrJ2AlbGNPJoDE9shlcndoaUQxYzNiZRi05ySSsWhE0AZeGINUnamTokbtJCedqz8QxwO4rCiPNaaSFBbZilcezOUMspo4YcDoME+Fs5AUobzODSpSWL8yU3uwoMiI96cVJOwpkZn9rWtFuzSgcOsJ3YinYm1Qbg71PEJqJNfwF41apWAdYb8YyGDlJ+gE1AEbKHcngKpCrwXhRUcSBTZbYVINj5eG1na6Pz9UedjZX0/mrn/MVflv9klZAnziTASVpRQFCOnEF8Ix0DAVZ7xSkWSzkmyHCFV44+GlfdJtMEoBFOPNIkeIi/pqaIpR82kNvhsBXgZGEUkLmoDuw1nDVTHPhcnnP9Fi37NJhJGmMWSe9dSc++hzI34L4eNFsM7pwAnK2tZFjC6GRehbOJkwpB28nD50dA24Axyjge5jZSdSI2yM2OQZy+FoSZPrzWff+zzuWH3Wvvp+/fSVcvd7+72Pl0w8pBOupOU38IqCkrXX+Q3rrSvbRpTQioGiSNKn4cGTwlEP6ujCIhU8TWfo7JH/zUTlnkr4+JNWa8hKPsOGSC4LadjTu7Z37ofHyu9+VHvZWv2eb1VlBFSwQM9WmVG007cGdRx7OTwE1y2QuqfqtGYz7BEUrJuWFYXRznr8XKehgdcasNO1AqhgPPW2MB2D6vVgPDERyo8HWknYmKLT/pJX7eLNiLaLUnrOPMhZDjR05aJXQTE1bn+rfpzWvpn2/03tuySspnTFic6vTm5d6Xy1aJOxD5trOxtvvFNto/bjgB8JGTpLd5L71/zWo7byNi72Ridz2faXeh9YHtvDnwV7gGLAb3QI6x+A10aHutPZBbi5KQMDNX6JA6TaqNw/JFbBdMF95SzH2T/SqcqLypQ1pNMDMU+F33ZvhUtFhuvBBUda1JjgiXYLMDK9VGOYoDB/hBZm8L/IWcOMUdx4TFLKw4Yu6867HopCyn2fJhIEaNcF4qcL9STwqQOt7COLf108CJP8GM8auAro04G0eCv9BPAMiWW++jtFYo3PAUeiVcWI6oW1vQ+H9AxCDk4EF0+TSsEzaPR0hMMsyGWzhBGwEdMW2noyyvrU3TdmJvOV+A6cyOODIMMMZyS+qhX6MRcgQ4myM1wQNayU8bICBTrwRLhfmrz4DZy4Re1ZRP8AmmmFzPQh0W6cB4GR9UuIMvxHM7kxPMeMsNWPjAHZJcNwmjYnr/BDFggPkdjuaMkwQ2Zv2TpQEcNFUMs9kS9DT4vNpxN2kUzG8ksz4OYbyxcaf7/Rk0UubK34EhAGYXLHZbSfgKBPrAM7aCoFOxeufupBc+AdMJ3u7Xp9cscC1iIwGJu0PYrre92bv335YzxrxNZ2MZVuxsf9B5cjFbF4etqEp/K9CEDfpfluOm7yX2obd///tD7xxyys2waTM/1b23km6fTS+udu7dAtclcIQBQLG3+Sfy25NvHP316fnOygVAmNPe2fwsfbr+69OVHBNeY7o4gIlcUY+BUWAMSB9/zYExKswJmv/kc8i/n3jzGOl9c65z+Wp6c9va1/lH2JSd17cMI2DzkXdhRaziQKuzsr3zw1p6/iHfGSIRwYHV3lcXuDfnAUrnzqXOZ+e1aLP49NW8uOkm6ImBsJIb4cFpl/QIdFGPN3m0bGdH0mVgstVOKReqFjoJUGVmh2zDhOo2LwsN+y2awIWlHJq14MFXheOm6EIXxjezSosIdiKD3dYtCV+uoKvkjwyJRnXWSHQKCK77rbiRo7jqQ6qHeRz4YlvL6gRKfTmo2kfnntyPoeTWakfmQJ1Rx2hAI9vyWExSsp3KS4sGVIarFkmPgpGeecJSOZEBNwicbJf++cVxjhv7OwC7ab8VCeRA2wVqTg4UA5BjZ9QK3mwm3ixYVEOBMIc3nQHL6hmxws1jMGAEUUm0ICAINeATDSxMmCQ7i/e+SDc2d57c7H532zyOJL3xuPfZKk8S/rZ8W+6mSgngGvsUNRQ0ZZMHBBZkgE9XOZAtYgqm0DmstSHIQxiCKjFFo3fpkbBpjI7e5vnu/Ss8OUFbMiGXPP6akwiGZ2frAz4Z7eGlz7uXbnTXNrtfXchWCRzapO4Frg859GJWbplsF58ZEPLLTUhnNQlzARfL15RjsRhNHg6RhIsbA9YIiLF/FO7DZJ3tw4VRoI66fEQxA50sMPovT9P1r3SpYP7J0sf03BZ4Op3FgsOjMfhw2DT4uyfXOM+4XbbN7DiziqwuU4bwdFZZlsGsrgIK0jDnbDKPseVhA0b0bp7rfbEFGS3jUa7coJgwgFQ0bkN1aXT6iwnBDQbpzF7n1crkj4TubP0Mws1JvPPD2d2rN3MSb4u6Ha8bngxPQdQ+nhXzRA54HHSp4HVWRdQrDtqaE2CNKi+OF5jgfI4JJwbckqqGacw6XRH1IzaTVz1lEF2gJF6tMjamUaOPhfU6sKzC95oyMJ0Y31tAClvQt9MtGi1MnC5xkCUfDG8y0Ue7potMpktLXg0yLA29vAYVZVODkymdM4fZrHxgmtV/TDb54EUNxqJbtTR0OZMcnFfGsqBbpYcbnl+LaGA7/bsfDd2aKEKI8ksWXSG40440rv3SfD2ohzm8rc7FjfThBVFhubjW3Xz0y/KZna2N9OMznfOXec2lu/Jjuv3dr0+v717Z2F37Do/x+oPud++nF1nYatrpZkVV3KuQLCdU1NttqwlkN3l0jcF5xQrCxKtStb5pYiZwevKVtCP4Z9qN6ckwcX0wJ917H8D2vac/pGdv/bK8unvuL7tf3f9leQ2eu9+e7W485c+716/u3r6bPtyGn5CjdD7/n52fvt+9fCH98gInXqeBiYGLxG46k/mDqStR+7l9cHllGzIBSUgiCEB+373NuLhqjZ0esxDDa+9zwiFVUtlZ9/r9dGUtZ2aA3/F/1abLf4jDAFKojAp5CMpIzJQwv47hc7nOLT6zxHKi6ty4hZVRRgvnr0YG5jvdz5/07qzpGBN0E09XQHQwAzSts349Xb7A9U2pGaMpJ5K2oKNfFIpmVbT0EjorI2qpn9OtJAmDgSTzYaCbP+jEIzRLvsdaT0XONk+AKKoM2CBOojCYgQ3YNIOPuEG5Chk7fwC1MgHHrenBYGdddlkHcwpgspozezQrztorrDcbcw4fm7JACY1Jh4+NWZiuT1hZ7CsYIiTEqILUclqLjTnUZkTnPDqvtI7/3JMgMU8XhDpwz8+ix1DsJxKoqZ1cqVh5QEdk0kRcoqcUTA73pUNV36ueskrM0WYZ257pLbgI8BGHs6tQfnenBCSv8DR2t52MNDy3IjY1g1wii4B8VHkurkaTz+K6lCVk3vcEAxhGL/u+bZXZKXDUEZuuvDStVUwiOhvOZeVwRwOoHyg2FzibTdSjKv2uA63DKhi3VR5H61cBYC07K2udjfd2fr7fufRjZ/1i9+aT3v99qkXZhGQs1O0Ix0WG4tJhG8aeBxxjmVHhdnQUj2wAeqliH2vNToPiZLbfWVoaH+7bDQXe/ewBUMavR5RzQD6x9+ziSNsQT+i66Wlkha044j4ahqeeIbkYnJAhwH9QgJ3LcouUQAuwDx0i/IpEhNkslabEi4nHWAkEs6w2pk1gGIzUYX+S899lEX3zqxcWPJIKUUE5f42Mlm9FzKveY0AKYy/mlrAgHt7LML4oUJcXPEOidDyRvAmDgx0hUIfpY2MaOf2hOhbv2ZZkSidwgvRF6zCToaBK0P1VPMRHECIDeDN8N1nVzkrFfYUWAUWv/skrdCALInxdSmbt5RmuTBRPC+2kxaMweQCvyfvaIUE/h2ZG/ESFX2SPmF+sHhrwE5vx1yFmkFPFcmGl0O5MZumBrkBFUWvvsThqPE4GmlUcyzbAEBYOpBbCIi4yjBU3s7KiREGVyeLom+ONBQvtVTQI+3OLpwuC7wL2UMe0d/4cf89/7jz5CEvxW492b/ycXTa0TZ0yo+VcqVEILO/pnz3XyWc7/FhPEYt3oORCaU4MJjsylFbRM4upxTkRqQALpy/9iFWns9/v/HTZCKfV/njebLNFwdpdvgo5ieAkb4WBRO/SpkKB35wgHHaxI1OvzoNL6Y0n6UORcXWvbgEAnm5p0ltN174BeFwmnZVlAM+30im08iFIFvlLj/7/TQBGiP1z4f10fxpggGzsHe2L+Y1CqfMAGa9mxkRgbotcgFk6GSGyfhDb6t69q2Z4QY2+O/aCw49iFuPyO3MDySgclpWIaBsn6cRyzXoeXyua2RydjLcVhktLmkaVtEhWDfCf75Trng8e134lBGBu4JT/EHqBzYnP4Z24M/GeeOOk/rxHxPRLSxa2A3GLsHm1++imomVa6lejhGSVEI6jDe4j+B/1UkK1brIrPCbAiUyWJfpuk7kk5P+EkmV70tiHG/1FBMFYnaV5k+wd53JFE4BKa5Q6FMdub4r2THZFyEK4qC/fgLfRgNpZlHOp/yC3akSO0d5h4+7y+u6ZD/sjR+ktYJeozJHaK1PIJQkFLjcLZ4YnDUOduhZ1vVQhQ1OGYjgDMwblIfWMIdtuSLrA7WpB0jANqnqMzqukQXKeJ247W//bu31GlMbRtGOnQXflPBOEdscms2WZKuMtNdce7DXImkdsmAJa5gZVGKw5i5qc0/XLne/P49XWT2t8w/TDG52Nu/J6jzsUob9tA154SpXEIG04DskzjeYoSRqUcPWSjXGQL0xTvO3G6x9aI/MQqVESz3twaPB1EhKX9Qrz3oByVvbQWi55WO6Qvvv4UW69CTEV3bia6u/20iWiuiM0EQBTsEdO9Ub+snyGnz4VNnXXt9ONzd33tiD9gphg56ct/bLU8NJciHVgX6NSQBxDAyhr6+UgNptJoK9biw2xSq++wGhR3KsrToSaqs03yZp8OSvSm486n1zhhcnOnc87N24pXRnagRFRH45bod6fWwP+9u4voz6uLJtXzH0aH/q1wvYE0y4jG/mO+dNg6C68EPCkjo2gYmLFIP0aXaajC1M3zpxbLHwVlW3juD6r3A2xZ0LXt+OiNyVNRm6YfBlcghuhHcq1v2HLmMy2iprUHNnUpk0q6lVz9mxQG7E5ra8xTTXbafLMqNH77hT9uXbZgaGQ6gsRbZkHD+bFxu/N9c5NXtiY5BLT79a5SprNtkN35qvZdyaOvvZN1aMxeL3WnqIvfZk3FQxdx+boi/CGfo81OMVYwi+ih6/BOXIR8iiMnpEyvnjftPFl+6SuGvq+24z3Fl6fSkgIp1venkrHGk19iBVttQwbk7MK+0iqozVk61BEHDwSCGmW9PUnVD/2KBCy7m0JY9qtntonJeYhQAD7IaJ/9f5IMNf39xGM0PRm9LWZzQ+FJfrx3MvClrd8AwTXs9IL/6o3vg2owg8lOw+YORSlAmZtdr/EaxVjQbmWZIzrbwbTLN2jJPjfcgT3ZRB7UytBGqRqJf+hBgKnZMzGuzAMbIYtEmmGuYj3Bg9blsvNzeQk1wHcn45oHlLf0AzAVDLSl4soyHw7LaJhzk7Fb/3XXXKhyE6zLmYsqGaVv+z+n1PCw6gLy52zF/KbyT0UaDP+xaZvLU7CpsAbt3ZXH/Tu3LQcPT4anGhIcrATeB/BWublVYA7VHlk4K0b2Ndavj+aFvQLVq63RYVDl4jGESwaffMJtop8cgNbLz/5Np8oGGzmU2SWhQ0OnZWPYfWvT6/zxk0lh86H5zt3/5xur6brD7BAenmld/ty986V9PqnWF6H7IyLUvFJjygH2hIjQs1YZYSZ+1isSm79a07RhVo4H1glKg8Zxn9leI2CP8K+3bMOHlRf/BSEftmqahL5/0EXYLoCwD9fXKSsgAc7v0rrLiYnkMrrHcW8YZI3HqNUA4amTed0rOZ4LRfDUJafW3ptH4e5+Pqzl2xIZiTFqTaHwr94Mb4PMOpRX3Qf8y8UtMmNYZ9UgP6hGmlX6NKA5HdDE44N2Wa3M+qs/M6iIBVt6+Akh3x3IcRgX3HI/Owr9mp4sYmMYU/4qXTkzTQSCy8PxNMEsXxaT6wh29Qh+G2hyxEYwxA7clr2zf7aOUs+2A4NKmmKXFWzVs5in6CjXOkQRdU7943edGUmqO1+Eys+0mRrubXe/elT8tfH+I/87YOPSPZVIvspnFFB3cHhNB06RN6idSyGsbpTTGZdYLkXsAJVQmebYeRGnr9A5rzYm/YpJKq+z+CVyLyXNECOJJyj0XzEP9XA/fmHAVigYrVUOGSQdeaZnHX4Ly1h6+3SkjIEDTd+DZ7BiB88mFkH1sAhCvIgXUxDC7oF2BfPo1SIWH2OfZpdVFLIPqPm3Cr9y/g4xjWcbX8HNIo68A==","engine-bridge.js":"eNrlPGuTFEW23/kVyYaxXcU0zeArdodFAkdc2VUgHNwbN4aRqO7O7i6npqq3qpqZdpgIWEUBGQEVkIcPFlzFEWQRZS4g98dIP+aTf+Gec/JRmdU9A7t64364hjpZ+Th5Xnny5DmZvWnDOraBvdoKE7Z718v/yfww8aucpQ3OWgmPCwlLeMArKa+yl/a+8jKrRpXWDA/TIvSEXl6qa6DrnybYbBQH1RLC3NvwE+ZVvWbKY9bwEhZGrBlHM82Uxa2AJ0UW82bgVTgOZqlXh5oqr3mtIGWVKEkBKNT8aWL3LlbxKg1eRKBRzLwAAIZe6h/gLGqm/oz/JnxEITTUo9hPGzMltj0IAK8ZD3CMmjym9gTAQDVSVo5aoaAHMd20znFctvU5Nr+OsQJQzZI09itpYQt8+zXmzPphNZot7d9fiWZq7T08fR7HPx/71Tr/y2YX6EhbccgKMfeqbRoV8FTzbbzhxV4FmbCVha0gUO1NHlb9sP4qT5DiraxAIyuAaAq8bbawTuClOFyq83RHQPx6vr2z6hQEO3di54KbjeYBDvWraw6G5mxEjRgCg0JvhhdZTbCDiE/bTR7VWI2t3wo41lphBZlZcIGRcTTLQj7LdsRxFDuF3g+HOzcu9C68LTTl4fJi96Nvuydv/3ToRIGNMAQNfwo/HVr8+f6J/tJ7vb/f7X+92Dt2tHvpm58O/Q0oUJysbWELGXJespfPETcOFNmMNwelp0bxH8JyAmQV1p0DbKtgL9sGnGRj7IBbSgK/wp1RGmQQe8ALWlwzF4Wu2eDzANlA7HdoiNCA9dTyaJq7tz7oXjrGDLmw/v3lzpEvupffESQSSEUmAi0JdA4elApgEJ7w9C8K1wP/Z8iaWG6VwgB0zMaqnzS9tNLYcQC0y6EZqVQg3ApFUKVyq1yGRT/G0hjgLLirciLHg2o5JylcOl4ce22on5wSUNK4bWvr+O6J/S88L1QWNJvX/JBXC+y3v2XbcWjJT+ivI/q5roYoKkD9wFgAQczZ77L5hYy11K8U8LCeNgbBSUMxANWqtwinHjmSK604Bu6ZdkMwwJHih4YxJQgeOAWwlti54G7LlGnA+mwr4TihZ0X25DPPukWCBkbeR7nY8Cao9lEQxVgTJlJiLLVYGTdTggPSCrwk3S0sOWwzW1FoCa1qkpjVWoL6GcfVNtdqHCo2gUgqLQiSV/Vrte01IADJw4bxKExxDyI6XDmFJSYaDris39S5eaF76evOO4vdby533v66c+LsQVlFH5sAYJI62N8FS0TjxgZXdsVremU/8FNkX068ck/jsFQEe6T2JP5MM+CKWMEmbY4Rd7u7ArNHbLl2dyF6r9kM2vlpqFKzVIx+MYi84SAqAUdltEFQ5RrzVpQGJQM0ko6NRwk4Bm3UfJtIkMAwnmxHlF+Ooumhs0WttOanA1PBdqg1eTd1meBp8sgZiT25gUOnrUVBlQNr1q8XSuel3otUNZF6aQuWForMbtnjpY2Cm19DCfUfvl9pgIZpHj7bEE2HFfvsqK3uJljEZjWoAtOhMJ96cihMadQAYN685ZaaoA+shJ8GsAa0+0LfRblbjaldD9YYGSgo4TIrysHm+hqzvhy3aOlftey40p6rwcrQjSlUiyajiwZ71Ahy/FDUEquiNHxjtpNHvRe0Kdi0iU3AQqk0NkZh0GaIYVhveQE4sr6X8GQL7ODgQgc+sC/kB2A58CoosnKiybaAPyz1mzzlkgD7Z86brFD2p/3QLwA9TaAXVKQGA1mdh2C1KyyZ9WeSlg/EeeD6JZVGFAWsFfq1KJ7RQwQ4Gid7ZMPSiHkHIr/KUGyAOfOA6sDDkwKwdgYkhD1YzQvAoxb8KGml3v3a3hd37t2//eWd2yd2TOBWTsyZLHS//ajz2d3OzfugSoWHy8dW7n3auX8SPyQ5upRgMZ2FQ4XPK+DT62ao22jVTRUl8N75H/vHbmGf3u2Pso/Zhp/yrNfKvdOyoQzHk2lowKG3j8jKGDwJquqfW9T9Wsb43q1jWW/4kKWmH0pYK/feknVtHgTRrJzhh89lbT3mPDTg3V5SIFoxmDvZ/fDNrHtb/PXaoq175Yxs6189pXAEZ9AAuvKuIrIO6qz+0rTYevyQbE38ADRPgr32saztXjsvS1HshXWD+O533/WvfEJ9oHT5CsGQOqPKs6D1hBIsIVQcassgfH65e2kR2zvXl+Gjc/QH+W0raVazX9VoGJ0vvuu8dUYiIj4UTPrAEpwOq3Lx6M8q6Gmiv4yJ8NsA/8EJCW7an4nCSLLn+9uS4HZrGkyllNM/bsi+GnjdkkT/yvnO9VOkK59dhw+ia9qPUwn19nuSjpVDV/p3l2QPASzTkYsf9T4igay8/6UsefFMFKtCS8qwf/1O58qSxChsxbA2Mx6I70FuHvkI2Lby1vsktFYYtpkSp/iq+3Ggv3LSPHeu/3eaDI7wUVhPPOLnX/2mFxnof3+r/8XXRHkaVWDR1olRTS9M240okSq/cvj9/jufyI6gOvUG/pfoLyY+M7yvnu18cQ6b34B1zAnhCngykhNffNu/vERzNpDbtI6jVmIrc2f5R6W2uI+oMhanoNdUtk+HwLMXfXGMFqc1dVYqsqfxtFrCHmDb3+ROYdeLfx5HVzN6OZrl8TiYe8elSUsyKOJsmty/b+PUyKY6zMigq67fl2SV2T6Lm0kTtjg2HYJ2sXFYWBxkWYGtAs/2CfgvaQMkzRLslQp73YQtEByWRHfHM3pmpMd37R/f/cqe3a/tegFNtG2zSzWw9a94TaceR60mkkuFUs3H+IwzhzWbJve1ngLaN+5r/b5Wq01J73jORb9qTh2jntvKnnQl9UkUp47jFcvEwLLqspF5skjEKlcL9incP/fCdpM4sTfrGmdE6fErqThSGNCryDY/PaoOoMC37WiDEyZ3h2wDoo1R1jKjGrY1PtfE9UfBpATjGtt3vcD+2uJxu2T6PJr5W+kY/iqv75hrOgUHwyEmc0tvRH7oFA6CUzgCYiUboY7fkg78o3VAA0Y1eGIzKwyeVkokZ9CifUnx5/snfjp0eMvP9y9uAoVylYieB9PJvdCIk2x+kgAtmCwmZ+TFKHZwU3ct91NKfkAxkN110giQ5wx3PCxngnDJXyZwNt4C3jZ5qEavg2IJ4JcLJSvNgLopOK6LLt8kgpkaQFrohfDOE4cEU2RRrZZw5CVQGsDxBoubMYo0bx0UQZegwdQsGm97s+BBvoCRCXQfjcgLjVaaqj1a0JjUC8bEvAl4hZNggAa8TMMhFv5hFgZCVP6IHEiYYFxCrFCice3eKdZBRwrqOQWw9StXHvS/e7d7FneONY8/FiThsyVGnEXNwEOp0SgaFQmCOR05EPQKuC255GqXnlhEjXBWoALFJFyECxZJxH5sJmcHEN1dBi9k4CLXQVSKLja0ad42zYGYGFbbvrnRUQpPqhYBQo9GpJHiUsNLHADiDqJLzV61Ss2qUoSALfap0IeslpJyBFFq2iyGwYFz2VxsweSiHXdCSO6qbAwzHtnDBEtDPETJojREbBOYFFhdshbYCcvEhjrbiEx2TppEwAkrnFKgCq4eSSqCfIERHMO4o1tk8Q/EDLlwZOXISKY5atZInrep+yR107yVnBFdBpmht2k015ohoneJKkEp5WfglXlAB1oM7Jz+sXMKPZjNz2RM0ObCq6Mobb5KKNiGvDU+adnOGb7BHKoqbEaSW0XBdxEvMuep8qQS+02RxwCNkjBRNrJo9LDq9EcY4eFVfrzZmNIzwLZrbtoy3jFnBeLcTJx51CpBJNx4Qx1UrJ/hyiIeqQ+TkAFQwtJ55QAlpOGqoaByOVmblrGEJ+R23hsR+w/aSazL4Jf8sBK0ABnR6Lru2hqzN+dNYN0A+jO4bnl1l9AwCznJ4DWxU/MM4qYWxvD5xpFR/86EisOPMaHcC0rNVtJw5ll+tRfFki0ykT8C5+iAz2d1UFkk954BI1I0tA5OjtNjFtM2sKdAzhZZG9iTMhpGwZN12f8VSnmXEcGSw0gFWMSe3BVKQVTxAj4OzpMXc6csq13RB0ka6CF2CWoXhmojTEAle89NvRjV4xU40MISn0NfSpRhzWymXFWR7WrNlEEiwgshoNoJVe5iK7SgbLahaBDkvBAEdF9y4TPlbCj2yNiW9Dw008jlI7yLEv0RgYC7tmui3KgxOWpB+V65aJaOsWGUGeq9sMJVYKvEstwGxhShftZrJ+gvw4ZO0SZwrAXMLFVbwFDYAa5TNGFkTpKCnSq34HjBQHIM6quVqMqrGCDzwxoHMqoyOPaS54Pu8jZ2DVUEAEVQ4c1UDPcpogkmyguAlF2792JzjWJb2elo+549O7a/un3X+I4hYayVd0+vLN0oFGWcZeXz69bn0g0Kn+CBE5QJ0PVj9WV9cFWwolMS1D0LMsWqxGAz3iUaxSFG96WAV67vyvFDEi7FfnRfEQDKAz58UwKmKJTujKEoRQCGo/LDbh+Rwyg+poeBcHI9u9c+Fk3da+dV4WNziIg75UddOSNa+1dPiULng7OdM5ctPmEcLDeuf25RjqOQnsHTVn6K3g+fSxIoXGdSzvNge7eOyb4UEdRlcxxGBQe4tKS4tGR1pehfXmz33lLq8JbZWUQWB/nfu3Rf8L/36XdaEFDZ++SiFASujKxoMUkMxgINFtzSg4lbcrQqW4yTc0NBzE0c1MMFB+V4/WFFLAUALBAAsZgyABTA1BDgS5RNXkkIUBAQiGkagmSaPQqkoJi2pJi2ZI6ScsmNApGLUSR7s2yNRfHnsVR03lN03jtt8xlXem668z/KKaAgkKQlrweJJW8PguUiJXr1lChgDY0WqyQ3x+Gbcg4oUC9a7lpiXjs/4AwaB4mOKNP4h8uLnVMnVi6fNBFscLDjUaUB1t/3cIFXtSpiwpZT9qgSBZGho3ZDS7dkvDxzR64OKKilAfa0rowU+owsq8hQ/0x2xoI2hQ1wNayRRo0e+nD5up62c/J4/2/XRHmGV/3WjBouv2R8S1YCuBbmlqxqI8Z7W+KRxp5fb+iJUZSLt+SMi3Jq2LoDbYtnvQN5W7zyj286Nx/giLM3dLkZhe3U8wOUBwZUjW9cGMYn3RLT3xnUi+c1MCj3HyAq6SxsqNAtkWVmfSggCS2HuiiaADuHb3c/+UzKkT57t2+IT0z/ECatpmGoHtyggHqhd+crOeruvf7xfwpkyjGG8uXfRBUGNqCHy8sABESPw5dgunvIqhNH4F9Rid1ZuRUaRVLJqIXHF2zI4tD/+C/4V8L68Xjn+LHu93dwtZ25DZ+9QyfFJ9hM0OSyR8HvTMiiItMC1V2DUSNqeFIzDCYySnXunjvcOfqO/iSe6ZlmwfHJvrDJrMrgnX6n+y0uVa8RmfPgErlx+uH9b5E8KghSy1EZHMhUlnI79YnT3c8+RCquXjC3rRnwTn21ytWqSGPuTWffqlnUm/bs/nLnn1elu0BlmENtz17VR0MhYUQz5Ti/lfZvfdg/hLaq4qUMXNZEJnDeOyWqodB7bxnK3UvfI7ujOdUry5OInpgwuX5K94y9ctmXIIsyZWKP7C0uy5Hvnekdu6ZHeqE/4wW5zv0vP0BOf35dFMAEhfKPxLhz5Fjvg5uiz8rnf9OfDS8wcy6X7q+cvIy8CbwkIXsKxjP7SJpwCPAqgWVPLx7qnj1NusYr06IJQZ27gvx58P7Du3dFeSYKyHflXittw4kunjaAwHK68kCiRwVaQIC/R/dIc9+JqvAqFZ7Aaa+dr/AtFJdudJZ/ENBFocG9KqiyzNr27nwqqvuf3O5/8kPve7QUcHYoR3opy6+BtLFOFBtJ4mE54sEUcT5DLFO9OtNrJGRlPtZOx8qEcZYvHkw160yzkWhWmWMrcaxyu1lqN3MHRINKGuucsZFultlmM9kss8I6KaxzwnZ+LDsHju/SITMryD94ololybTODFrpcMYq2SYR08CME5V01oltxqiPnXZia+ed8oTsCOtwrG78KtRYuY1B2l6f9Da+OTXibBtjouSOPGER+IuJ+aPM5shET+6qEYb3hlFEuZ41o1o67yPksFruZ5W8z9o5H5n5VHKg3WM2iqs6zBjFCXN+o89xv3HpfD+Nu1sKm1ja4BjHihh1EcDQg8QLPGK/+Q2rRhzvrqdobmBvBE8GgwKJl/pJrc08GXaj4LYxUcnKoWkmD01VUn5pzVxllv3F4/+ZO+AKihywiAYw4XAy4SHqGC0Q81rCyb0FPdnYjHnNnxPhNfAUiG4zMIARnXaCFEEr+DAZDxU0HzQBjCnmdsq8Ao46+M30UiBUN39ktnSESZADOdFa7NXJqht5ESN11MSYEoAX4x4/h5mlCpCh4PsmlAIbVYFDsNxAkSMb/kDz6Dzd/LC4KuYIDIslNF1rNY2nCFjyH37aEA1FObHr2nFqgofJHE28iKOK+i0K3ZGtYmadBhnM/eQDjmLkyEg23xqE0gVWiyZ7pT6CJnfIbDmCBAQztJhniBnAlRmUaJqHA9pAWSKZIQIqsnkyUsRAVfEHtvnJLZkopTY1Yi/hliSlqRDibGZWzhiEDIAxTal+ds5DmivqZGwliFCGpGCBXwTcR6yuRhqFDGFT88XKNwq8XQrmEpGCu6IWOQKqIr4MHLXaKGXhePHOBqFRnPSnEBDIMhdTFxcIaIgR2X2FVoQys7MNzOGKTkUyjUmrLBJFCS7ezBygBwcGmJfqJbKo68H2+1BwLfPY8JLtWkDbUeucBlgicD6ni0xuG/PGHXxRo54O4P3CLAW/phOgBynw+cyHGY4H6+c18T669BuyizmlDSPbXn9ifsFxD07um9q3b4ps8b59T/w2dxHDuvSxbez1g5Ovw949uvH3Uy4mtNQMIwxatz5htroCbYWnu8oNBx1HX/OSw+9ydxzoRql5dyG3EvPb1eD9B/0mbPXrvOI+hLlGswsRIkUBGGL0vwxqvJcqEC87X2FelLDuRNT1bQgxA12HsF2Z3JXmVpi9XPgFdxoQrf+nNxp+vesETz2Tv04gUKSDwSDxUK0urA/cQyCPzE/ba15GKGr4w64lSAF7s5kRGkjpEzaZgmkajeTWmHHPI+9bAzwL/qMT7uKGnHztonefofcHshygeRWRLhpWrdVs+9L2EOUV7hUXGjJScCeWGdmdGa9HhzRb7BvNsSIIXhG9oK0+NGE/PyTt/hLZr2HHiiF7hlIFtWcMu6zxkp/aFk5JAnPUsF+7qx1jhsyXcRl2Uz1pzveTVLh5HppeFD2FErgN8UnZIH/NwUyRVQJrtcOrNBAU8ZOMkynXbLeDLq5ryVz4B1i/ZcEgYSHv+Cip4HsjC2XwgkaHezPrM+GvZhj5HNjlzJoT6+kRAdCRrXB1coTFt3kU1ttodrHIsu7ylgJZAWkEKuHYo2yWKk+OTsmXYDCFqpQ1xezdXPZ2bnxXduNBTuJYrJUM2mYvsjFTC9UVzKfd7Drms+atoCJ7+mnz+oS4PCH4NpJXrg1PZ3WZ1mx4SsllYd0wrg27SLHx17tG8agbE/kLE/Z9iYMHc7clml6dT9BDOPPChHVfwroucfDg7wbuSgg/JM8H6YGs7pso04ceygATjdMP/X9EIeqS+XXmkZ/FUqk0t+BufW7OLSr/pigvVtAofa1CENvwwmog/BZhGMSjsDH5Jkx8OfpFZ7pHvpJy5sX94QX5wFA/n1JPi8VLxVXeK8GwYu5Jope0w4r1Ek1fzdMPE/XF05Onelfv9q99Kp5GZndPcy8ZQW+GvlnM7VBlDgYOwcsHX6rVm/XAHuEQH85DQEgUHOCOAuW4uY7o4snOTiwuhaV7/RketcDnKLLNzw7spl5NPMLNzZt/vy9Y6NA6cMQYfH8s0d4mweDlPg1C39lRYqE+q0iD3q2FdbyWI2EieAFV+sYL1rvOYbIie2yBdQexkIRmeKDrBQe5BDQZPjo3L/Tevtw9e7N34W0h2t73p7qfXsI34woTOjXuxdvxUSsGh0A942NVjkG0hDWiWeaF9g84yNfC+LMRQIEvLtusLmKpZp0vzvU++spEJNO0VR+zuoZePJr+3KqwmC1fwA5j9ppod5ePrJy/qtdIhrPxetbEcvjPRTwe/oVCHmnjBSRYBevsqM6Nwmasfc6UfV0FNYoSrvsSaNMVlyBtu+GnfEYeRkVQhtzbOeH/igMTqDkVoEr+2sOc9fRcxFJkk9Vg+yE41ZCfRVg5dL5zarH/5Qf9Y7fwasKlr3oXb3SOLWY/l1CJkv3VcumNJAqNH0ZgytCJoSuHl7sfvmtYOfsts+vQ9Ftyj0zNV/7z8mk/diyZjJNVJmnZQtPif5wXBaaFwBfTa1n0xzjk63u4oqc8/A5wuL/0XufIUcEgwSyLjWuuE9G/c/Vs/8tDYqnnNxL9/PuXLpd/gYHWA5PHW0NDX6PYC0g/Vf9VxaEJHnx8kmmRDJOEv+jdiPkGBQGFjoVKNq/pM2ZHzQFNVrdWh7x2gA2VngwYb5dGpYeVqHOckx2i6M4uLCNxQ1lfTE70zf9kjUv/mdetLzbnMNJ3/TVcuu1vuu/P4ksjNMX6jES5rKlhK1MwVq/NeXW72o5r8LkmcYmuTtum1fz9oTX1Rb30AaVMpDXKQjBZbMp60D8waiIXtzJDVkNHkiMjngzYU4OFt1WGfBy7j/FTJMoiWp0m7GiXtcvoibc9asMZwGuNnSc/NchV/dCTWpN6YszBrLIPdU9d6tx8T7gwD5evw8Yjbd8da1sSK7Jzd0n8itLKu4vgiomxllVVMY+4TvFg4sA2Nv/4W8wCG9OctuyLgPn4xh4Q7R4923nwqTApJp29i7e7738h7PoQ7OVeMCHtyS82TJhSkqdC8xa/9VrLmNMxKC1KVg43XcQXARmsws4w5XWcg3phAmtUFJ7baj50GqYDxw4h54jCQYmDVqAmXP8Ymh5L+spEAFmWtdim1NmstV8eIUV6eKb/4uHVVGY35fcw6+nSwlRAzJjWIN2GTEHfu6AWZ28Okth5cKLzzqJQF2hdOfzfnSP4uXLiW4DQv/KJxYOFIQvQxAKOKHAI9qv42xiYxpZPAeTpKpn1RbTG8pY9PGwHXGX9Z1oUbpUmjcv1AoeZUpYj/fedxF/TTWSPtyGwYcvgX9rFBb/zuk6n4l9Xn+wg6YBKdY6+2z15UZrQByfkmjp6rn/5K9Cw/o3joGSPWESZCi2sW+MZ4tRjObISgZwLO+z3hFxnQGbDOV9Eh8Z4XigEkb34W+1Vo/JB/vfcZYXD2OM/tFyku4DkcGmfSN3xWfsXGPEJevkNwKVUizl/k0u/T/0qnfKjdO7U8SrimSQY9CTTInqcaz8wlGCB9DTCNA2mzHbPhiDhJo/Tdgl/UdJRwTmAR3DdIXZd/xgiHif37NjLuh8uPvzx0s/3L2CmTo4buGUwz/CEhr+YJ1KlY1LD1IyTYuCUg4QgG+cX3GzFZw+J4zh/yQWj2lygNjmOPH1tJ6FVJpZOgRxw0CoIUcqdekRghuAPrmf4U5IxImN7ySpxd8lqTTQzUdOE+V/TXIBj3br/AfZSxqo="};
const UI_EXPECTED_HASHES = {"control.html":"1a522fa5e786129c50fae257df10a87cfdd26e2cb546c1ad94d5e4aa322b1e9c","control.css":"700598a78285377e7dc59d889e19d62d388b23cb2b7792eb460c3b1ef791107b","control.js":"94d34e1285b5b4c1889383ad2e833a19afe01f87f94ff709b167c218a97d1ca4","engine-bridge.js":"ced3134ec5383256ce914a7c6df016540be4df7e333a25f66e8034b42d483267"};

// v2.3: The PET control surface MUST NOT use file://. A Windows extraction
// folder can contain literal percent-escape sequences or be incomplete.
// Load the self-contained PET UI directly from verified in-memory resources.
// The user's selected prompt HTML is still external, unmodified, and rebindable.
function embeddedUi(name) {
  const payload = UI_FALLBACK_BUNDLE[name];
  if (typeof payload !== 'string') throw new Error('Missing embedded PET asset: ' + name);
  const bytes = zlib.inflateSync(Buffer.from(payload, 'base64'));
  const actual = crypto.createHash('sha256').update(bytes).digest('hex');
  if (actual !== UI_EXPECTED_HASHES[name]) throw new Error('PET UI integrity mismatch: ' + name);
  return bytes.toString('utf8');
}
function createPetUiDataUrl(isDiagnostic) {
  let page = embeddedUi('control.html');
  const css = embeddedUi('control.css');
  const js = embeddedUi('control.js');
  // No network, no relative file, no script src, no stylesheet link.
  const csp = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; base-uri 'none'; form-action 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; object-src 'none'">`;
  page = page.replace(/<meta\s+http-equiv="Content-Security-Policy"[^>]*>/i, csp);
  if (!page.includes('rel="stylesheet" href="control.css"')) throw new Error('PET HTML CSS slot missing');
  page = page.replace('<link rel="stylesheet" href="control.css" />', '<style>\n' + css + '\n</style>');
  if (!page.includes('<script src="control.js"></script>')) throw new Error('PET HTML script slot missing');
  page = page.replace('<script src="control.js"></script>', '<script>\n' + js + '\n</script>');
  if (isDiagnostic) page = page.replace('<html lang="zh-Hant">', '<html lang="zh-Hant" data-pet-diagnostic="1">');
  if (page.includes('src="control.js"') || page.includes('href="control.css"')) throw new Error('PET UI still references local resources');
  return 'data:text/html;charset=utf-8,' + encodeURIComponent(page);
}

function petAssetFolder() {
  const issues = Object.keys(UI_EXPECTED_HASHES).filter((name) => {
    const candidate = path.join(__dirname, name);
    try {
      const data = fs.readFileSync(candidate);
      return crypto.createHash('sha256').update(data).digest('hex') !== UI_EXPECTED_HASHES[name];
    } catch (_) { return true; }
  });
  if (!issues.length) {
    renderLog('PET UI asset check: PASS (all bundled UI files verified)');
    return __dirname;
  }
  // Use the per-user writable app directory. Works even when the Downloads
  // extraction folder is read-only or contains an incomplete PET/pet directory.
  const recovered = path.join(app.getPath('userData'), 'recovered-ui-v2.2');
  fs.mkdirSync(recovered, {recursive:true});
  for (const [name, encoded] of Object.entries(UI_FALLBACK_BUNDLE)) {
    const bytes = zlib.inflateSync(Buffer.from(encoded,'base64'));
    if (crypto.createHash('sha256').update(bytes).digest('hex') !== UI_EXPECTED_HASHES[name]) {
      throw new Error('Embedded PET UI integrity check failed: '+name);
    }
    fs.writeFileSync(path.join(recovered,name), bytes);
  }
  renderLog('PET UI assets restored automatically: ' + issues.join(', ') + ' -> ' + recovered);
  return recovered;
}

// GPU accelerated transparent windows may appear empty on some Windows machines.
// PET uses DOM and CSS, so prefer the stable software compositor by default.
const safeWindow = process.argv.includes('--safe-window');
const gpuRenderer = process.argv.includes('--gpu-renderer');
if (process.platform === 'win32' && !gpuRenderer) app.disableHardwareAcceleration();
const RENDER_LOG = path.resolve(__dirname, '..', 'PET_Render_Log.txt');
function renderLog(message) {
  try {
    fs.mkdirSync(path.dirname(RENDER_LOG), { recursive: true });
    fs.appendFileSync(RENDER_LOG, '[' + new Date().toISOString() + '] ' + String(message) + '\n', 'utf8');
  } catch (_) {}
  console.log('[PET]', message);
}
process.on('uncaughtException', (err) => {
  renderLog('Uncaught error: ' + (err?.stack || err));
  try { dialog.showErrorBox('ComfyUI PET start error', String(err?.message || err) + '\n\nSee PET_Render_Log.txt'); } catch (_) {}
  app.quit();
});
process.on('unhandledRejection', (err) => renderLog('Unhandled rejection: ' + (err?.stack || err)));
app.setName('ComfyUI PET HTML Binder');
const DEFAULT_HTML = path.resolve(__dirname, '..', 'ComfyUI_PNG_Prompt_Viewer.html');
let BRIDGE_CODE = '';
let PET_UI = '';
let ASSETS_DIRECTORY = __dirname;
let settings;
let petWindow = null;
let engineWindow = null;
let engineReady = false;
let engineLoading = false;
let petExpanded = safeWindow;
let currentlyLoadingPath = null;
let quitting = false;
let storeTimer = null;
const nativeFolderTokens = new Map();
let nextNativeFolderId = 0;
let nativeFsShimCode = '';
let bindingInfo = null;
let currentBindingTask = null;
// PET v2.9: the rail has one fixed screen-space anchor. App-controlled resizing
// must not be mistaken for a user drag (which would cause cumulative drift).
let railAnchor = null;
let railSide = 'left';
let settingWindowBounds = false;
let releaseProgrammaticMove = null;


function clamp(n, lo, hi) { n = Number(n); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : lo; }
function settingsFile() { return path.join(app.getPath('userData'), 'pet-binding.json'); }
function readSettings() {
  let obj = {};
  try { obj = JSON.parse(fs.readFileSync(settingsFile(), 'utf8')) || {}; } catch (_) {}
  const pathValue = typeof obj.htmlPath === 'string' ? obj.htmlPath : DEFAULT_HTML;
  return {
    htmlPath: path.resolve(pathValue), bindingMode: obj.bindingMode === 'manual' ? 'manual' : 'auto',
    folderPath: typeof obj.folderPath === 'string' ? obj.folderPath : '', size: clamp(obj.size ?? 100, 70, 130),
    opacity: clamp(obj.opacity ?? 100, 45, 100),
    x: Number.isFinite(obj.x) ? obj.x : null,
    y: Number.isFinite(obj.y) ? obj.y : null
  };
}
function saveSettings() {
  try {
    fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
    fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2), 'utf8');
  } catch (e) { console.error('Unable to save PET settings:', e); }
}
function emit(message) {
  if (petWindow && !petWindow.isDestroyed() && !petWindow.webContents.isDestroyed()) {
    petWindow.webContents.send('pet:event', message);
  }
}
function publicConfig() {
  return {
    htmlPath: settings.htmlPath, exists: fs.existsSync(settings.htmlPath),
    htmlVersion: bindingInfo?.version || '', sourceHtmlPath: bindingInfo?.sourcePath || '',
    autoBinding: settings.bindingMode !== 'manual',
    folderName: settings.folderPath && fs.existsSync(settings.folderPath) ? path.basename(settings.folderPath) : '',
    size: settings.size, opacity: settings.opacity,
    engineReady, engineLoading
  };
}
function dimensions(open) {
  const scale = settings.size / 100;
  return {
    width: Math.round((safeWindow ? 490 : (open ? 472 : 88)) * scale),
    height: Math.round((safeWindow ? 660 : (open ? 614 : 572)) * scale)
  };
}
function clampVisible(position) {
  // Select the monitor by the collapsed rail, not by the expanded panel.
  const marker={x:position.x+position.width-25,y:position.y+30};
  const work=screen.getDisplayNearestPoint(marker).workArea;
  const maxHeight=Math.max(dimensions(true).height,dimensions(false).height);
  return {
    x: Math.round(clamp(position.x,work.x,Math.max(work.x,work.x+work.width-position.width))),
    y: Math.round(clamp(position.y,work.y,Math.max(work.y,work.y+work.height-maxHeight))),
    width:position.width,height:position.height
  };
}
function railBounds(open) {
  const compact=dimensions(false);
  const size=dimensions(open);
  const anchor=railAnchor || {right:petWindow.getBounds().x+petWindow.getBounds().width,top:petWindow.getBounds().y};
  const work=screen.getDisplayNearestPoint({x:anchor.right-compact.width/2,y:anchor.top+30}).workArea;
  let side='left';
  if(open && !safeWindow && anchor.right-size.width < work.x &&
      anchor.right-compact.width+size.width <= work.x+work.width) side='right';
  // right-edge of the collapsed rail remains unchanged for both orientations.
  return {
    bounds:{x:Math.round(side==='right'?anchor.right-compact.width:anchor.right-size.width),
      y:Math.round(anchor.top),width:size.width,height:size.height},
    side
  };
}
function resizePet(open) {
  if (!petWindow || petWindow.isDestroyed()) return;
  const target=railBounds(open);
  railSide=target.side;
  const b=target.bounds;
  const old=petWindow.getBounds();
  // Set the panel orientation before bounds so the rail stays pinned visually.
  petWindow.webContents.send('pet:event',{type:'layout',side:railSide});
  if(old.x!==b.x || old.y!==b.y || old.width!==b.width || old.height!==b.height){
    settingWindowBounds=true;
    if(releaseProgrammaticMove)clearTimeout(releaseProgrammaticMove);
    petWindow.setBounds(b,false);
    releaseProgrammaticMove=setTimeout(()=>{settingWindowBounds=false;releaseProgrammaticMove=null;},350);
  }
  petWindow.webContents.setZoomFactor(settings.size / 100);
  petWindow.setOpacity(settings.opacity / 100);
  petWindow.setAlwaysOnTop(true,'floating');
}
function newPetWindow() {
  const { width, height } = dimensions(false);
  const area = screen.getPrimaryDisplay().workArea;
  const pos = clampVisible({
    x: settings.x ?? area.x + area.width - width - 28,
    y: settings.y ?? area.y + Math.round((area.height - height) / 2),
    width, height
  });
  petWindow = new BrowserWindow({
    ...pos,
    show: false,
    frame: safeWindow,
    transparent: !safeWindow,
    backgroundColor: safeWindow ? '#16191f' : '#00000000',
    hasShadow: safeWindow,
    thickFrame: safeWindow,
    roundedCorners: false,
    resizable: safeWindow,
    minimizable: safeWindow,
    maximizable: false, fullscreenable: false,
    alwaysOnTop: true, skipTaskbar: false, autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(ASSETS_DIRECTORY, 'preload.js'),
      nodeIntegration: false, contextIsolation: true, sandbox: true,
      webSecurity: true, backgroundThrottling: false
    }
  });
  railAnchor = {right:pos.x+pos.width,top:pos.y};
  railSide='left';
  petWindow.setMenuBarVisibility(false);
  renderLog('PET window created: ' + JSON.stringify({safeWindow, gpuRenderer, bounds:petWindow.getBounds()}));
  petWindow.on('moved', () => {
    if (quitting || settingWindowBounds || !petWindow || petWindow.isDestroyed()) return;
    // Only direct desktop dragging changes the saved location. Resizing,
    // expanding, collapsing and updating opacity never modify the anchor.
    const b=petWindow.getBounds();
    const compact=dimensions(false);
    const newRight=railSide==='right' ? b.x+compact.width : b.x+b.width;
    railAnchor={right:newRight,top:b.y};
    settings.x=Math.round(newRight-compact.width);
    settings.y=Math.round(b.y);
    clearTimeout(storeTimer);storeTimer=setTimeout(saveSettings,300);
  });
  petWindow.on('closed', () => { petWindow = null; if (!quitting) app.quit(); });
  petWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  petWindow.webContents.on('did-fail-load', (_e, code, description, url, isMainFrame) => {
    if (isMainFrame !== false) renderLog(`PET embedded UI load failed: ${code} ${description} ${url.slice(0,120)}`);
  });
  petWindow.webContents.on('preload-error', (_e, preloadPath, error) => {
    renderLog('PET preload error (' + preloadPath + '): ' + (error?.stack || error));
  });
  petWindow.webContents.on('render-process-gone', (_e, detail) => {
    renderLog('PET renderer crashed: ' + JSON.stringify(detail));
    dialog.showErrorBox('PET 顯示失敗', 'PET 畫面載入程序異常。\n請執行 Launch_PET_安全視窗.bat。\n紀錄：' + RENDER_LOG);
  });
  petWindow.webContents.on('console-message', (...ev) => {
    const obj = ev.length > 1 ? ev[1] : ev[0];
    const msg = typeof obj === 'object' && obj ? obj.message : String(ev[2] || obj || '');
    if (/error|failed|exception/i.test(msg)) renderLog('PET browser console: ' + msg.slice(0, 1200));
  });
  let shown = false;
  // A fallback watchdog makes failed renderer startup observable in the log.
  setTimeout(() => {
    if (shown || !petWindow || petWindow.isDestroyed()) return;
    renderLog('PET UI load timed out (8 seconds). Showing diagnostic window.');
    petWindow.show(); petWindow.moveTop();
  }, 8000);
  petWindow.loadURL(createPetUiDataUrl(safeWindow)).then(async () => {
    if (!petWindow || petWindow.isDestroyed()) return;
    const health = await petWindow.webContents.executeJavaScript(`(() => {
      const rail = document.querySelector('.pet-rail');
      const css = rail && getComputedStyle(rail);
      const bounds = rail && rail.getBoundingClientRect();
      return {rail:!!rail, display:css?.display, width:bounds?.width,
              height:bounds?.height, api:typeof window.comfyPet};
    })()`, true);
    renderLog('PET frontend loaded: ' + JSON.stringify(health));
    if (!health.rail || health.width < 20 || health.height < 100) throw new Error('PET controls are missing or clipped.');
    petWindow.webContents.setZoomFactor(settings.size / 100);
    petWindow.setOpacity(safeWindow ? 1 : settings.opacity / 100);
    // Unlike showInactive(), show() also activates the desktop PET on first run.
    petWindow.show(); petWindow.moveTop(); petWindow.focus();
    shown = true;
    emit({ type: 'engine', config: publicConfig() });
  }).catch(async (e) => {
    renderLog('PET UI failed to open: ' + (e?.stack || e));
    if (!petWindow || petWindow.isDestroyed()) return;
    // Never leave a silent taskbar-only blank window if local UI failed.
    try {
      const msg = String(e?.message || e).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
      await petWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(
        '<meta charset="utf-8"><body style="background:#252934;color:white;font:14px Segoe UI;padding:16px"><h3>PET UI failed</h3><p>' + msg + '</p><p>Run Launch_PET_安全視窗.bat</p></body>'));
      petWindow.show(); petWindow.moveTop(); petWindow.focus(); shown = true;
    } catch (fallbackError) { renderLog('Fallback display failed: ' + fallbackError); }
  });
}
function engineAllowed(contents) {
  if (!contents || contents.isDestroyed() || !engineWindow || engineWindow.isDestroyed()) return false;
  return contents.id === engineWindow.webContents.id;
}
function setupFileSystemPermissions() {
  // The chosen HTML may need File System Access to load the user's original JSON folder.
  // File selection and writes still happen through THAT HTML's existing UI and code.
  session.defaultSession.setPermissionRequestHandler((contents, permission, callback) => {
    callback(permission === 'fileSystem' && engineAllowed(contents));
  });
  session.defaultSession.setPermissionCheckHandler((contents, permission) =>
    permission === 'fileSystem' && engineAllowed(contents));
}
function newEngineWindow() {
  engineWindow = new BrowserWindow({
    title: 'ComfyUI HTML（PET 背景引擎）', width: 1390, height: 890,
    minWidth: 800, minHeight: 600, show: false, backgroundColor: '#101116',
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false, contextIsolation: true, sandbox: true,
      preload: path.join(__dirname, 'engine-preload.js'),
      webSecurity: true, backgroundThrottling: false
    }
  });
  engineWindow.setMenuBarVisibility(false);
  engineWindow.on('close', e => {
    if (!quitting) { e.preventDefault(); engineWindow.hide(); emit({ type: 'full-hidden' }); }
  });
  engineWindow.on('closed', () => { engineWindow = null; engineReady = false; });
  engineWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//i.test(url)) shell.openExternal(url).catch(() => {});
    return { action: 'deny' };
  });
  engineWindow.webContents.on('will-navigate', (event, url) => {
    const page = pathToFileURL(currentlyLoadingPath || settings.htmlPath).href;
    if (url.split('#')[0].split('?')[0] !== page) event.preventDefault();
  });
  engineWindow.webContents.on('render-process-gone', (_ev, details) => {
    engineReady = false; emit({ type: 'failure', error: 'HTML 背景引擎意外結束：' + details.reason });
  });
}
async function loadEngine(filename) {
  const target = path.resolve(filename);
  if (!/\.html?$/i.test(target)) throw Error('請選擇 .html 或 .htm 檔案。');
  if (!fs.existsSync(target) || !fs.statSync(target).isFile()) throw Error('找不到指定的 HTML：' + target);
  if (!engineWindow || engineWindow.isDestroyed()) newEngineWindow();
  engineLoading = true; engineReady = false; currentlyLoadingPath = target;
  emit({ type: 'engine', config: publicConfig() });
  const previousPath = settings.htmlPath;
  try {
    await engineWindow.loadFile(target);
    const shimReady = await engineWindow.webContents.executeJavaScript(nativeFsShimCode, true);
    renderLog('Native folder shim: '+shimReady);
    const result = await engineWindow.webContents.executeJavaScript(BRIDGE_CODE, true);
    if (result !== 'ready') throw Error('無法注入 HTML 相容介面。');
    const stat = await engineWindow.webContents.executeJavaScript(
      "window.__comfyPetBoundBridgeV1.dispatch('status', {})", true);
    if (!stat.ok || !stat.data.ready) throw Error(stat.error || '此 HTML 缺少 #promptInput，無法綁定。');
    engineReady = true;
    if (settings.folderPath && fs.existsSync(settings.folderPath)) {
      try {
        const attach = await engineWindow.webContents.executeJavaScript(
          'window.__comfyPetNativeFsV2.restore()', true);
        renderLog('Native folder auto-restore: ' + JSON.stringify(attach));
      } catch (folderError) {renderLog('Native folder auto-restore failed: '+ folderError);}
    }
    settings.htmlPath = target;
    saveSettings();
    emit({ type: 'engine', config: publicConfig(), status: stat.data });
    return { ok: true, config: publicConfig(), status: stat.data };
  } catch (e) {
    engineReady = false;
    const message = e && e.message ? e.message : String(e);
    if (previousPath !== target && fs.existsSync(previousPath)) {
      try {
        currentlyLoadingPath = previousPath;
        await engineWindow.loadFile(previousPath);
        const restored = await engineWindow.webContents.executeJavaScript(BRIDGE_CODE, true);
        engineReady = restored === 'ready';
      } catch (restoreError) {
        console.error('Failed to restore previously selected HTML:', restoreError);
      }
    }
    emit({ type: 'failure', error: message + (engineReady ? '（已恢復上一份 HTML）' : '') });
    return { ok: false, error: message, config: publicConfig() };
  } finally {
    engineLoading = false; currentlyLoadingPath = null;
    emit({ type: 'engine', config: publicConfig() });
  }
}
// AutoBind v2.8: PET itself migrates old DT/DQ/etc paths to the stable entry.
// Runs on startup, on Choose HTML, and whenever the user presses Reload.
// If any upgraded engine fails, revert the stable file and keep the last-good engine.
async function loadLatestEngine(preferredPath) {
  if (currentBindingTask) return currentBindingTask;
  currentBindingTask = (async () => {
    const original = settings.htmlPath;
    const sync = htmlAutoSync.refresh({
      selectedPath: preferredPath || original,
      fallbackDir: path.resolve(__dirname, '..'),
      envDir: process.env.PET_HTML_DIR || ''
    });
    if (!sync.ok) {
      renderLog('PET AutoBind failed: ' + sync.error + ' ' + (sync.skipped || []).join(' | '));
      emit({type:'failure',error:'自動更新 HTML 失敗：'+sync.error});
      return {ok:false,error:sync.error};
    }
    if (sync.skipped?.length) renderLog('PET AutoBind skipped invalid files: ' + sync.skipped.join(' | '));
    renderLog('PET AutoBind: ' + JSON.stringify({version:sync.version, source:sync.sourcePath,
      active:sync.path, updated:sync.updated, notice:sync.notice || ''}));
    const loaded = await loadEngine(sync.path);
    if (loaded.ok) {
      settings.bindingMode = 'auto';
      bindingInfo=sync;
      saveSettings();
      emit({type:'engine',config:publicConfig(),status:loaded.status});
      return loaded;
    }
    // A browser runtime failure can still occur after a syntax-valid HTML update.
    if (sync.updated) {
      try {
        if (htmlAutoSync.restore(sync)) {
          renderLog('PET AutoBind rollback restored previous stable HTML');
          const oldLoad=await loadEngine(sync.path);
          if (oldLoad.ok) {
            bindingInfo={...sync, updated:false, version:'回復前版', sourcePath:sync.path};
            emit({type:'failure',error:'新版 HTML 載入失敗，已回復上一份可用版本：'+loaded.error});
            return {ok:false,error:'新版載入失敗，已回復前版：'+loaded.error,config:publicConfig()};
          }
        }
      } catch(e){renderLog('PET AutoBind rollback failed: '+e.message);}
    }
    return loaded;
  })();
  try{return await currentBindingTask;}finally{currentBindingTask=null;}
}

async function actionInHtml(name, args) {
  if (!engineReady || !engineWindow || engineWindow.isDestroyed()) {
    return { ok: false, error: 'HTML 尚未綁定或尚未載入。請到「··· → 設定」選擇 HTML。' };
  }
  const command = 'window.__comfyPetBoundBridgeV1.dispatch(' +
    JSON.stringify(String(name)) + ',' + JSON.stringify(args || {}) + ')';
  try { return await engineWindow.webContents.executeJavaScript(command, true); }
  catch (e) { return { ok: false, error: e && e.message ? e.message : String(e) }; }
}
function fromPet(event) {
  if (!petWindow || petWindow.isDestroyed() || event.sender.id !== petWindow.webContents.id) {
    throw Error('PET IPC source not authorized.');
  }
}

// PET v2.4: Native Windows directory adapter for the HTML's showDirectoryPicker.
// No domain JSON logic lives here. Only user-selected folder IO is handled.
function nativeFolderName(rel) {
  if (typeof rel !== 'string' || rel.includes('\\') || rel.includes('\\0')) throw Object.assign(new Error('Invalid folder path'),{name:'SecurityError'});
  const parts = rel === '' ? [] : rel.split('/');
  if (parts.some(x => !x || x==='.' || x==='..' || /[<>:"|?*\\\\\u0000-\u001f]/.test(x))) throw Object.assign(new Error('Invalid file name'),{name:'SecurityError'});
  return parts;
}
function nativeFsRoot(token) {
  const entry = nativeFolderTokens.get(String(token));
  if (!entry || !fs.existsSync(entry.path)) throw Object.assign(new Error('Folder no longer available: select it again'),{name:'NotFoundError'});
  return entry;
}
function safeNativeTarget(folder, rel) {
  const parts = nativeFolderName(rel);
  const target = path.resolve(folder.path, ...parts);
  const check = path.relative(folder.path, target);
  if (check.startsWith('..') || path.isAbsolute(check)) throw Object.assign(new Error('Path escapes selected folder'),{name:'SecurityError'});
  const rootReal = fs.realpathSync(folder.path);
  // Existing symlinks/junctions must not escape the user's selected root.
  let ancestor = target;
  while (!fs.existsSync(ancestor)) { const parent=path.dirname(ancestor); if(parent===ancestor) break; ancestor=parent; }
  const real = fs.realpathSync(ancestor);
  const realRel = path.relative(rootReal,real);
  if (realRel.startsWith('..') || path.isAbsolute(realRel)) throw Object.assign(new Error('Symlink escapes selected folder'),{name:'SecurityError'});
  return target;
}
function nativeFolderResult(folder) {return {token:folder.token, name:path.basename(folder.path)};}
function rememberNativeFolder() {
  const folderPath = settings.folderPath;
  if (!folderPath || !fs.existsSync(folderPath) || !fs.statSync(folderPath).isDirectory()) return null;
  const folder = {token:'data',path:path.resolve(folderPath),write:true};
  nativeFolderTokens.set('data',folder);
  return nativeFolderResult(folder);
}
async function chooseNativeFolder(owner, mode='readwrite') {
  if (!engineWindow || engineWindow.isDestroyed()) throw new Error('HTML engine not available');
  const readOnly = mode === 'read';
  const response = await dialog.showOpenDialog(owner || engineWindow, {
    title: readOnly?'選擇素材資料夾':'選擇 ComfyUI JSON 資料夾',
    defaultPath: (settings.folderPath && fs.existsSync(settings.folderPath)) ? settings.folderPath : app.getPath('documents'),
    properties:['openDirectory']
  });
  if (response.canceled || !response.filePaths?.length) throw Object.assign(new Error('Folder selection cancelled'),{name:'AbortError'});
  const folder = {token:readOnly?'extra'+(++nextNativeFolderId):'data',path:path.resolve(response.filePaths[0]),write:!readOnly};
  nativeFolderTokens.set(folder.token,folder);
  if (!readOnly) {settings.folderPath=folder.path;saveSettings();emit({type:'engine',config:publicConfig()});}
  renderLog('Native folder selected: '+ path.basename(folder.path) + ' ('+mode+')');
  return nativeFolderResult(folder);
}
function registerNativeFolderIpc() {
  ipcMain.handle('pet:native-fs', async (event,action,payload={}) => {
    try {
      if (!engineAllowed(event.sender)) throw Object.assign(new Error('Untrusted folder request'),{name:'SecurityError'});
      let data=null;
      if (action==='remembered') {data=rememberNativeFolder();}
      else if (action==='select') {data=await chooseNativeFolder(engineWindow,payload.mode);}
      else if (action==='forget') {settings.folderPath='';nativeFolderTokens.delete('data');saveSettings();data=true;}
      else {
        const folder=nativeFsRoot(payload.token);
        const filePath=safeNativeTarget(folder,payload.relative);
        if (action==='inspect') {
          if (payload.relative==='') throw Object.assign(new Error('Cannot open root as file'),{name:'SecurityError'});
          if (payload.create && !folder.write) throw Object.assign(new Error('Read only folder'),{name:'NotAllowedError'});
          if (!fs.existsSync(filePath)) {
            if (!payload.create) throw Object.assign(new Error('File or directory does not exist'),{name:'NotFoundError'});
            if (payload.kind==='directory') fs.mkdirSync(filePath);
            else fs.closeSync(fs.openSync(filePath,'wx'));
          }
          const stats=fs.statSync(filePath);
          if (payload.kind==='directory' ? !stats.isDirectory() : !stats.isFile()) throw Object.assign(new Error('Wrong file type'),{name:'TypeMismatchError'});
          data={kind:payload.kind};
        } else if (action==='read') {
          const stats=fs.statSync(filePath);
          if (!stats.isFile()) throw Object.assign(new Error('Not a regular file'),{name:'TypeMismatchError'});
          const bytes=fs.readFileSync(filePath);
          data={bytes:new Uint8Array(bytes),mtime:stats.mtimeMs};
        } else if (action==='write') {
          if (!folder.write) throw Object.assign(new Error('Folder is read only'),{name:'NotAllowedError'});
          if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) throw Object.assign(new Error('File does not exist'),{name:'NotFoundError'});
          if (!payload.bytes || typeof payload.bytes.length!=='number' || payload.bytes.length > 64*1024*1024) throw Object.assign(new Error('Invalid or oversized file contents'),{name:'QuotaExceededError'});
          const temp=path.join(path.dirname(filePath),'.pet-tmp-'+crypto.randomBytes(8).toString('hex'));
          try {fs.writeFileSync(temp,Buffer.from(payload.bytes));fs.renameSync(temp,filePath);}
          finally {try {if(fs.existsSync(temp))fs.unlinkSync(temp);}catch(_){}}
          data=true;
        } else if (action==='enumerate') {
          if (!fs.statSync(filePath).isDirectory()) throw Object.assign(new Error('Not a folder'),{name:'TypeMismatchError'});
          data=fs.readdirSync(filePath,{withFileTypes:true}).filter(d=>d.isFile()||d.isDirectory()).map(d=>({name:d.name,kind:d.isDirectory()?'directory':'file'}));
        } else if (action==='remove') {
          if (!folder.write) throw Object.assign(new Error('Folder is read only'),{name:'NotAllowedError'});
          if (payload.relative==='') throw Object.assign(new Error('Cannot remove selected root'),{name:'SecurityError'});
          if (fs.statSync(filePath).isDirectory()) fs.rmSync(filePath,{recursive:!!payload.recursive});
          else fs.unlinkSync(filePath);
          data=true;
        } else throw Object.assign(new Error('Unknown operation'),{name:'NotSupportedError'});
      }
      return {ok:true,data};
    } catch(e) {
      // Keep structured DOM error names; the bound HTML checks NotFoundError.
      return {ok:false,name:e?.code==='ENOENT'?'NotFoundError':(e?.name||'NotAllowedError'),error:String(e?.message||e)};
    }
  });
}

function registerIpc() {
  ipcMain.handle('pet:config', e => { fromPet(e); return publicConfig(); });
  ipcMain.handle('pet:choose-folder', async e => {
    fromPet(e);
    try {
      const dir=await chooseNativeFolder(petWindow,'readwrite');
      if (engineReady) {
        const result=await engineWindow.webContents.executeJavaScript('window.__comfyPetNativeFsV2.restore()',true);
        renderLog('PET settings folder binding: '+JSON.stringify(result));
      }
      emit({type:'engine',config:publicConfig()});
      return {ok:true,folderName:dir.name};
    } catch(err) {return err?.name==='AbortError' ? {canceled:true}: {ok:false,error:String(err?.message||err)};}
  });
  ipcMain.handle('pet:select-html', async e => {
    fromPet(e);
    const chooser = await dialog.showOpenDialog(petWindow, {
      title: '選擇要綁定的 ComfyUI HTML', properties: ['openFile'],
      defaultPath: fs.existsSync(settings.htmlPath) ? settings.htmlPath : app.getPath('documents'),
      filters: [{ name: 'HTML', extensions: ['html', 'htm'] }]
    });
    if (chooser.canceled || !chooser.filePaths.length) return { canceled: true };
    // A version-named file (or stable entry) opts into auto-update in its directory.
    const chosen=chooser.filePaths[0];
    const basename=path.basename(chosen);
    if (htmlAutoSync.parseVersion(basename) || htmlAutoSync.STABLE.test(basename))
      return loadLatestEngine(chosen);
    const result=await loadEngine(chosen);
    if(result.ok){settings.bindingMode='manual';bindingInfo=null;saveSettings();}
    return result;
  });
  ipcMain.handle('pet:reload-html', async e => {
    fromPet(e);
    return settings.bindingMode === 'manual' ? loadEngine(settings.htmlPath) : loadLatestEngine(settings.htmlPath);
  });
  ipcMain.handle('pet:open-full', e => {
    fromPet(e);
    if (!engineWindow || engineWindow.isDestroyed() || !engineReady) {
      return { ok: false, error: '請先綁定可用的 HTML。' };
    }
    engineWindow.show(); engineWindow.focus();
    return { ok: true };
  });
  ipcMain.handle('pet:action', (e, name, args) => {
    fromPet(e);
    const allowed = ['status','setPrompt','optimize','apply','clear','characters',
      'chooseCharacter','applyLook','outfits','searchOutfits','applyOutfit'];
    if (name === 'copy') {
      const txt = typeof args?.text === 'string' ? args.text : '';
      if (!txt.trim()) return { ok: false, error: '沒有可複製的提示詞。' };
      clipboard.writeText(txt); return { ok: true, data: { length: txt.length } };
    }
    if (!allowed.includes(name)) return { ok: false, error: '不允許的操作。' };
    if (name === 'setPrompt' && (typeof args?.text !== 'string' || args.text.length > 300000)) {
      return { ok: false, error: '提示詞過長或格式不正確。' };
    }
    return actionInHtml(name, args);
  });
  ipcMain.handle('pet:expanded', (e, open) => {
    fromPet(e); petExpanded=!!open; resizePet(petExpanded); return { ok: true };
  });
  ipcMain.handle('pet:appearance', (e, size, opacity) => {
    fromPet(e);
    settings.size = clamp(size, 70, 130); settings.opacity = clamp(opacity, 45, 100);
    resizePet(petExpanded); saveSettings();
    return publicConfig();
  });
  ipcMain.handle('pet:close', e => { fromPet(e); app.quit(); return { ok: true }; });
}
const lock = app.requestSingleInstanceLock();
if (!lock) app.quit();
else {
  app.on('second-instance', () => {
    if (petWindow && !petWindow.isDestroyed()) { petWindow.show(); petWindow.focus(); }
  });
  app.whenReady().then(async () => {
    ASSETS_DIRECTORY = petAssetFolder();
    PET_UI = 'embedded://pet-ui/control.html';
    BRIDGE_CODE = fs.readFileSync(path.join(ASSETS_DIRECTORY, 'engine-bridge.js'), 'utf8');
    settings = readSettings();
    nativeFsShimCode = fs.readFileSync(path.join(__dirname, 'native-fs-shim.js'),'utf8');
    renderLog('PET startup: ' + JSON.stringify({electron:process.versions.electron, os:process.platform,
      safeWindow, gpuRenderer, petUi:'verified in-memory HTML/CSS/JS', htmlPath:settings.htmlPath, size:settings.size, opacity:settings.opacity}));
    setupFileSystemPermissions(); registerIpc(); registerNativeFolderIpc(); newPetWindow();
    if (settings.bindingMode === 'manual') {
      if (fs.existsSync(settings.htmlPath)) await loadEngine(settings.htmlPath);
      else emit({ type:'failure', error:'手動綁定 HTML 已不存在，請重新選擇。' });
    } else {
      await loadLatestEngine(settings.htmlPath);
    }
  }).catch(e => {
    renderLog('PET startup rejected: ' + (e?.stack || e));
    try { dialog.showErrorBox('ComfyUI PET start error', String(e?.message || e)); } catch (_) {}
    app.quit();
  });
}
app.on('before-quit', () => { quitting = true; if (settings) saveSettings(); });
app.on('window-all-closed', () => { if (!quitting) app.quit(); });
