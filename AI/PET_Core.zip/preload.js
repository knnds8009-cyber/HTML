'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('comfyPet', Object.freeze({
  config: () => ipcRenderer.invoke('pet:config'),
  chooseFolder: () => ipcRenderer.invoke('pet:choose-folder'),
  selectHtml: () => ipcRenderer.invoke('pet:select-html'),
  reloadHtml: () => ipcRenderer.invoke('pet:reload-html'),
  openFull: () => ipcRenderer.invoke('pet:open-full'),
  action: (name, args) => ipcRenderer.invoke('pet:action', name, args || {}),
  expanded: (value) => ipcRenderer.invoke('pet:expanded', !!value),
  appearance: (size, opacity) => ipcRenderer.invoke('pet:appearance', size, opacity),
  close: () => ipcRenderer.invoke('pet:close'),
  onEvent: (callback) => {
    const handler = (_event, payload) => callback(payload);
    ipcRenderer.on('pet:event', handler);
    return () => ipcRenderer.removeListener('pet:event', handler);
  }
}));
