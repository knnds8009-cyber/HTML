'use strict';
// PET v2.4 - Restricted native File System Access adapter.
// Only loaded in the bound HTML engine window; prompt logic remains in HTML.
const {contextBridge, ipcRenderer} = require('electron');
const invoke = async (action, payload) => {
  const result = await ipcRenderer.invoke('pet:native-fs', action, payload || {});
  if (!result || !result.ok) {
    const e = new Error(result?.error || 'PET native folder operation failed');
    e.name = result?.name || 'NotAllowedError';
    throw e;
  }
  return result.data;
};
contextBridge.exposeInMainWorld('__petNativeFS', Object.freeze({
  select: (mode) => invoke('select', {mode}),
  remembered: () => invoke('remembered', {}),
  read: (token, relative) => invoke('read', {token, relative}),
  write: (token, relative, bytes) => invoke('write', {token, relative, bytes}),
  inspect: (token, relative, create, kind) => invoke('inspect', {token, relative, create, kind}),
  enumerate: (token, relative) => invoke('enumerate', {token, relative}),
  remove: (token, relative, recursive) => invoke('remove', {token, relative, recursive}),
  forget: () => invoke('forget', {})
}));
