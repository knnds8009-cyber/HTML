'use strict';
(() => {
  const api = window.comfyPet;
  const $ = id => document.getElementById(id);
  const shell = $('petShell');
  const text = $('promptText');
  const panels = ['edit','more','character','outfit','settings'];
  let currentPanel='edit', expanded=false, busy=false, editing=false;
  const diagnostic = document.documentElement.dataset.petDiagnostic === '1' || new URLSearchParams(location.search).has('diagnostic');
  let typingTimer=null, latestResult='', lastEngineText='', settings={ size:100,opacity:100 };
  let chosen={char:'',series:''};
  if (diagnostic) { expanded=true; shell.dataset.open='true'; }
  const status = (msg, error=false) => {
    $('message').textContent=String(msg||'');
    $('message').classList.toggle('bad',!!error);
  };
  const handle = (reply, successMsg) => {
    if (!reply || reply.ok===false) { status(reply?.error||'操作沒有完成。',true); return null; }
    if (successMsg) status(successMsg);
    return reply.data || reply;
  };
  const escapeText = str => String(str ?? '');
  const setCount = () => { $('charCounter').textContent=text.value.length+' 字元'; };
  const setInput = (v) => { text.value=escapeText(v); lastEngineText=text.value; setCount(); };
  const setResult = (v) => {
    latestResult=escapeText(v);
    $('resultText').textContent=latestResult||'尚無新的優化結果';
    $('resultLabel').textContent=latestResult?'可套用':'尚無結果';
  };
  const chosenLabel = () => chosen.char ? (chosen.char+(chosen.series?' · '+chosen.series:'')) : '尚未選擇角色';
  function selectPanel(name) {
    if (!panels.includes(name)) return;
    currentPanel=name;
    panels.forEach(n => { $('pane-'+n).hidden=n!==name; });
    $('panelTitle').textContent=({edit:'Prompt PET',more:'更多功能',character:'角色外觀',outfit:'角色服飾',settings:'PET 設定'})[name];
    $('railInput').classList.toggle('active',name==='edit');
    $('railMore').classList.toggle('active',name!=='edit');
    if (name==='character') fetchCharacters();
    if (name==='outfit') fetchOutfits();
    if (name==='settings') updateConfig();
  }
  async function setExpanded(value) {
    expanded=!!value;
    shell.dataset.open=expanded?'true':'false';
    await api.expanded(expanded);
  }
  async function show(name) { selectPanel(name); await setExpanded(true); }
  function updateStatusData(data) {
    if (!data) return;
    $('statusLed').classList.toggle('ok',!!data.ready);
    if (!editing && typeof data.prompt==='string' && data.prompt!==lastEngineText) setInput(data.prompt);
    if (data.selected?.char) chosen=data.selected;
    if (data.folderState) $('statusLed').title=data.folderState;
  }
  async function updateConfig() {
    const cfg = await api.config();
    if (!cfg) return;
    settings={size:cfg.size,opacity:cfg.opacity};
    $('sizeRange').value=cfg.size;$('opacityRange').value=cfg.opacity;
    $('sizeValue').textContent=cfg.size+'%';$('opacityValue').textContent=cfg.opacity+'%';
    $('boundPath').textContent=cfg.htmlPath||'未綁定';
    $('boundVersion').textContent=cfg.autoBinding
      ? ('自動更新：'+(cfg.htmlVersion||'尚未辨識')+' · 最新來源：'+(cfg.sourceHtmlPath ? cfg.sourceHtmlPath.split(/[\\/]/).pop() : '等待同步'))
      : '自訂 HTML（手動綁定模式）';
    $('boundFolderPath').textContent=cfg.folderName ? ('已綁定：'+cfg.folderName) : '尚未綁定 JSON 資料夾';
    $('statusLed').classList.toggle('ok',!!cfg.engineReady);
    if(!cfg.exists) status('找不到綁定的 HTML，請選擇新的檔案。',true);
  }
  async function dispatch(name,args={},successMsg) {
    return handle(await api.action(name,args),successMsg);
  }
  async function sendPrompt() {
    if (!editing && text.value===lastEngineText) return true;
    const result=await dispatch('setPrompt',{text:text.value});
    if (!result) return false;
    lastEngineText=text.value;
    return true;
  }
  async function flushPrompt() {
    clearTimeout(typingTimer);
    editing=false;
    return sendPrompt();
  }
  text.addEventListener('input',()=>{
    editing=true;setCount();
    clearTimeout(typingTimer);
    typingTimer=setTimeout(()=>{flushPrompt();},280);
  });
  text.addEventListener('blur',()=>{if(editing)flushPrompt();});
  async function runOptimize() {
    if (busy) return;
    busy=true;await show('edit');
    try {
      if (!await flushPrompt()) return;
      status('正在交給綁定的 HTML 執行優化…');
      const data=await dispatch('optimize');
      if (!data) return;
      setInput(data.prompt);setResult(data.result);
      status(data.result?'優化完成。已由綁定 HTML 計算結果。':'優化已執行，但 HTML 未產生獨立結果。');
    } finally {busy=false;}
  }
  async function runApply() {
    if(busy)return;
    busy=true;try {
      if(!await flushPrompt())return;
      const data=await dispatch('apply');if(!data)return;
      setInput(data.prompt);if(data.result)setResult(data.result);
      await show('edit');status(data.message||'已呼叫綁定 HTML 的套用函式。');
    }finally{busy=false;}
  }
  async function runCopy() {
    if(!await flushPrompt())return;
    const value=(latestResult||text.value||'').trim();
    const data=await dispatch('copy',{text:value});
    if(data)status('已複製 '+data.length+' 字元。');
  }
  async function runClear() {
    if(busy)return;
    if(!await flushPrompt())return;
    const data=await dispatch('clear');if(!data)return;
    setInput(data.prompt);setResult('');status('已使用綁定 HTML 的清除函式。');
  }
  let searchToken=0;
  let characterPage=0;
  let characterTimer=null;
  const characterPageSize=80;
  async function fetchCharacters(append=false) {
    const q=$('characterSearch').value.trim();
    const id=++searchToken;
    const offset=append?characterPage:0;
    const data=await dispatch('characters',{query:q,offset,limit:characterPageSize});
    if(!data||id!==searchToken)return;
    if(data.selected?.char)chosen=data.selected;
    $('characterChosen').textContent=chosenLabel();
    const list=$('characterList');
    if(!append)list.replaceChildren();
    $('characterLoadMore').hidden=true;
    if(!q){
      $('characterSearchInfo').textContent='搜尋角色名稱、作品或外觀特徵；關鍵字可組合。';
      const p=document.createElement('p');p.className='notice';
      p.textContent='角色庫 '+data.databaseTotal+' 筆。輸入「金髮」「紅眼」「雙馬尾」等條件開始搜尋。';
      list.append(p);characterPage=0;return;
    }
    $('characterSearchInfo').textContent='找到 '+data.total+' 名符合「'+q+'」的角色（來源：目前綁定 HTML 的 cos_db.json）。';
    if(!data.list?.length){
      if(!append){const p=document.createElement('p');p.className='notice';p.textContent='查無符合條件的角色，請確認 cos_db.json 已載入，或換個外觀關鍵字。';list.append(p);}
      return;
    }
    data.list.forEach(item=>{
      const button=document.createElement('button');button.className='item';button.type='button';
      const title=document.createElement('strong');title.textContent=item.cn||item.char;
      const sub=document.createElement('small');sub.textContent=item.char+(item.series?' · '+item.series:'')+(item.seriesCN?'（'+item.seriesCN+'）':'');
      button.append(title,sub);
      if(item.preview){const preview=document.createElement('small');preview.className='character-match';
        preview.textContent='外觀：'+item.preview;button.append(preview);}
      button.addEventListener('click',async()=>{
        const result=await dispatch('chooseCharacter',{char:item.char,series:item.series});
        if(!result)return;
        chosen=result.selected||item;$('characterChosen').textContent=chosenLabel();
        list.querySelectorAll('.item').forEach(b=>b.classList.remove('active'));
        button.classList.add('active');status('已選擇角色，按「套用角色外觀」才會修改提示詞。');
      });
      list.append(button);
    });
    characterPage=offset+data.list.length;
    $('characterLoadMore').hidden=characterPage>=(Number(data.total)||0);
    $('characterLoadMore').textContent='顯示更多角色（已顯示 '+characterPage+'／'+data.total+'）';
  }
  async function runLook() {
    if(!await flushPrompt())return;
    const data=await dispatch('applyLook');if(!data)return;
    setInput(data.prompt);setResult('');status('已由綁定 HTML 套用角色外觀。');
  }
  // Outfit search state is intentionally separate from characterSearch.
  let outfitToken = 0;
  let outfitPage = 0;
  const outfitPageSize = 80;
  let outfitTimer = null;
  async function fetchOutfits(append=false) {
    const query = $('outfitSearch').value.trim();
    const id = ++outfitToken;
    const offset = append ? outfitPage : 0;
    const data = query
      ? await dispatch('searchOutfits',{query,offset,limit:outfitPageSize})
      : await dispatch('outfits');
    if (!data || id !== outfitToken) return;
    if (data.selected?.char) chosen=data.selected;
    $('outfitChosen').textContent='目前角色：'+chosenLabel();
    const list=$('outfitList');
    if (!append) list.replaceChildren();
    $('outfitLoadMore').hidden=true;
    if (query) {
      const count=Number(data.total)||0;
      $('outfitSearchInfo').textContent='跨角色搜尋：找到 '+count+' 套符合「'+query+'」的服飾';
    } else {
      $('outfitSearchInfo').textContent='未輸入關鍵字：顯示目前角色服飾（角色搜尋與服飾搜尋互不影響）';
    }
    if (!data.list?.length) {
      if (!append) {
        const p=document.createElement('p');p.className='notice';
        p.textContent=query ? '沒有符合條件的服飾。請確認已載入 cos_outfits.json，或改用其他關鍵字。'
          : (chosen.char ? '這名角色沒有可用的服飾資料。' : '輸入「比基尼」「白色」等關鍵字，即可搜尋所有角色的服飾。');
        list.append(p);
      }
      return;
    }
    data.list.forEach(item=>{
      const b=document.createElement('button');b.type='button';b.className='item';
      const h=document.createElement('strong');
      h.textContent=query ? (item.name+' · '+(item.cn || item.char)) : ('第 '+(item.index+1)+' 套：'+item.name);
      const role=document.createElement('small');role.className='outfit-role';
      role.textContent=[item.char||chosen.char,item.series||chosen.series].filter(Boolean).join(' · ');
      const tags=document.createElement('small');tags.textContent=item.preview||'無服飾標籤';
      b.append(h,role,tags);
      b.addEventListener('click',async()=>{
        if (!await flushPrompt()) return;
        const args={index:item.index,expectedName:item.name};
        if (query){args.char=item.char;args.series=item.series;}
        const r=await dispatch('applyOutfit',args);if(!r)return;
        if(r.selected?.char)chosen=r.selected;
        $('outfitChosen').textContent='目前角色：'+chosenLabel();
        setInput(r.prompt);setResult('');status('已透過綁定 HTML 套用服飾：'+r.outfit);
      });
      list.append(b);
    });
    if (query) {
      outfitPage=offset+data.list.length;
      $('outfitLoadMore').hidden=outfitPage >= (Number(data.total)||0);
      $('outfitLoadMore').textContent='顯示更多服飾（已顯示 '+outfitPage+'／'+data.total+'）';
    }
  }
  async function bindNew() {
    status('選擇你要使用的最新版 HTML…');
    const ret=await api.selectHtml();
    if(ret?.canceled){status('已取消，仍使用原本的 HTML。');return;}
    if(ret?.ok){
      // Preserve the prompt currently being edited while switching to a new engine.
      if(text.value.trim()) await api.action('setPrompt',{text:text.value});
      setResult('');
      await updateConfig();
      status('已綁定新版 HTML。PET 的優化、角色與服飾現在都由這份 HTML 執行。');
      const fresh=await api.action('status',{});
      if(fresh?.ok)updateStatusData(fresh.data);
      if(currentPanel==='outfit') fetchOutfits();
    } else status(ret?.error||'綁定失敗，請檢查 HTML。',true);
  }
  async function reloadNew() {
    status('重新讀取所綁定的 HTML…');
    const oldText=text.value;
    const r=await api.reloadHtml();
    if(r?.ok){
      if(oldText.trim())await api.action('setPrompt',{text:oldText});
      setResult('');const fresh=await api.action('status',{});if(fresh?.ok)updateStatusData(fresh.data);status('已重新載入目前的 HTML。');
      if(currentPanel==='outfit') fetchOutfits();
    }else status(r?.error||'重新載入失敗。',true);
    updateConfig();
  }
  async function setAppearance() {
    const size=Number($('sizeRange').value),opacity=Number($('opacityRange').value);
    $('sizeValue').textContent=size+'%';$('opacityValue').textContent=opacity+'%';
    settings=await api.appearance(size,opacity);
  }
  $('railInput').addEventListener('click',()=>{if(expanded&&currentPanel==='edit')setExpanded(false);else show('edit');});
  $('railMore').addEventListener('click',()=>show('more'));
  $('railOptimize').addEventListener('click',runOptimize);
  $('railApply').addEventListener('click',runApply);
  $('railCopy').addEventListener('click',runCopy);
  $('railClear').addEventListener('click',runClear);
  $('editorOptimize').addEventListener('click',runOptimize);
  $('editorApply').addEventListener('click',runApply);
  $('editorCopy').addEventListener('click',runCopy);
  $('collapse').addEventListener('click',()=>setExpanded(false));
  $('quit').addEventListener('click',()=>api.close());
  $('openCharacter').addEventListener('click',()=>show('character'));
  $('openOutfit').addEventListener('click',()=>show('outfit'));
  $('openSettings').addEventListener('click',()=>show('settings'));
  $('backCharacter').addEventListener('click',()=>show('more'));
  $('backOutfit').addEventListener('click',()=>show('more'));
  $('backSettings').addEventListener('click',()=>show('more'));
  $('characterSearch').addEventListener('input',()=>{
    clearTimeout(characterTimer);
    characterPage=0;
    characterTimer=setTimeout(()=>fetchCharacters(false),150);
  });
  $('characterLoadMore').addEventListener('click',()=>fetchCharacters(true));
  $('outfitSearch').addEventListener('input',()=>{
    clearTimeout(outfitTimer);
    outfitPage=0;
    outfitTimer=setTimeout(()=>fetchOutfits(false),160);
  });
  $('outfitLoadMore').addEventListener('click',()=>fetchOutfits(true));
  $('applyLook').addEventListener('click',runLook);
  $('chooseHtml').addEventListener('click',bindNew);
  $('chooseFolder').addEventListener('click',async()=>{
    status('選擇 JSON 資料夾…');
    const r=await api.chooseFolder();
    if(r?.canceled)status('已取消資料夾選擇。');
    else if(r?.ok)status('已選擇資料夾：'+r.folderName+'。請確認 HTML 的 JSON 載入狀態。');
    else status('資料夾綁定失敗：'+(r?.error||'未知錯誤'),true);
    await updateConfig();
    if(r?.ok && currentPanel==='outfit') fetchOutfits();
  });
  $('reloadHtml').addEventListener('click',reloadNew);
  $('openFull').addEventListener('click',async()=>{const r=await api.openFull();if(!r?.ok)status(r?.error||'無法開啟完整 HTML。',true);else status('完整版 HTML 已打開；完成資料夾授權後可關閉視窗回到 PET。');});
  $('sizeRange').addEventListener('input',setAppearance);
  $('opacityRange').addEventListener('input',setAppearance);
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'&&expanded)setExpanded(false);
    if(e.ctrlKey&&e.key==='Enter'){e.preventDefault();runOptimize();}
  });
  api.onEvent(ev=>{
    if(ev.type==='engine') {
      if(ev.status)updateStatusData(ev.status);
      updateConfig();
      if(ev.config.engineReady)status('已連線：'+(ev.config.htmlPath.split(/[\\/]/).pop()||'HTML'));
      else if(ev.config.engineLoading)status('正在啟動綁定的 HTML…');
    } else if(ev.type==='layout') {
      shell.dataset.side = ev.side === 'right' ? 'right' : 'left';
    } else if(ev.type==='failure')status(ev.error,true);
  });
  (async()=>{
    await updateConfig();
    const r=await dispatch('status');
    if(r){updateStatusData(r);status('已連線至目前綁定的 HTML。');}
    else status('尚未連線。請點 ··· → PET 設定 → 選擇 HTML。',true);
  })();
  // Reflect edits made in the temporarily visible full HTML, without overwriting PET typing.
  setInterval(async()=>{
    if(editing||busy||document.hasFocus()&&document.activeElement===text)return;
    const reply=await api.action('status',{});
    if(reply?.ok)updateStatusData(reply.data);
  },3000);
})();
